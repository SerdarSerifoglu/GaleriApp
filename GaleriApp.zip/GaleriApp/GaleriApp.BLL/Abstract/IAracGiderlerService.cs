﻿using System.Collections.Generic;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IAracGiderlerService
    {
        List<AracGiderler> GetAll();
        List<AracGiderler> GetByAracID(int aracId);
        void Add(AracGiderler aracGider);
        void Update(AracGiderler aracGider);
        void Delete(int aracGiderId);
        AracGiderler GetById(int aracGiderId);
        int AracGiderOlustur(AracGiderViewModel model);
        /// <summary>
        /// Araç Id'sine bağlı olarak aracın toplam giderini getiren metod
        /// </summary>
        /// <param name="aracId">Giderlerinin toplamı getirilecek aracın id'si</param>
        /// <returns></returns>
        decimal GetByAracIDToplamGider(int aracId);
    }
}