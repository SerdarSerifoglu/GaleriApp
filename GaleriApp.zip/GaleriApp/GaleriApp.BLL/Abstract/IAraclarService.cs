﻿using System.Collections.Generic;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;

namespace GaleriApp.BLL.Abstract
{
    public interface IAraclarService
    {
        List<Araclar> GetAll();
        void Add(Araclar arac);
        void Update(Araclar arac);
        void Delete(int aracId);
        Araclar GetById(int aracId);
    }
}