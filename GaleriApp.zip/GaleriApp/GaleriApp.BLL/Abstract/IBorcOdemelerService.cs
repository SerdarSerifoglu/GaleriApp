﻿using System.Collections.Generic;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IBorcOdemelerService
    {
        List<BorcOdemeler> GetAll();
        void Add(BorcOdemeler borcOdeme);
        void Update(BorcOdemeler borcOdeme);
        void Delete(int borcOdemeId);
        BorcOdemeler GetById(int borcOdemeId);
        BorcOdemeler GetByBorcId(int borcId);
        List<BorcOdemeler> GetByBorcIdList(int borcId);
        /// <summary>
        /// Borcun içindeki Son Borç Ödeme kaydını getirir
        /// </summary>
        /// <param name="borcId"></param>
        /// <returns></returns>
        BorcOdemeler GetByLastBorcOdemeInThisBorc(int borcId);
    }
}