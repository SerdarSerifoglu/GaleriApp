﻿using System.Collections.Generic;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IBorclarService
    {
        List<Borclar> GetAll();
        void Add(Borclar borc);
        void Update(Borclar borc);
        void Delete(int borcId);
        Borclar GetById(int borcId);
        List<Borclar> TestSP();
        Borclar GetByLastBorc();
    }
}