﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.BLL.Abstract
{
    
    public interface ICarilerService
    {
        List<Cariler> GetAll();
        void Add(Cariler cari);
        void Update(Cariler cari);
        void Delete(int cariId);
        Cariler GetById(int cariId);
        List<Cariler> GetNotIncludeId(int id);
        List<Cariler> GetbyCariTip(int id);
    }
}
