﻿using System.Collections.Generic;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IEkGelirlerService
    {
        List<EkGelirler> GetAll();
        void Add(EkGelirler ekGelir);
        void Update(EkGelirler ekGelir);
        void Delete(int ekGelirId);
        EkGelirler GetById(int ekGelirId);
        EkGelirler GetByLastEkGelir();
    }
}