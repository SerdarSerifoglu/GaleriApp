﻿using System.Collections.Generic;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IEkGiderlerService
    {
        List<EkGiderler> GetAll();
        void Add(EkGiderler ekGider);
        void Update(EkGiderler ekGider);
        void Delete(int ekGiderId);
        EkGiderler GetById(int ekGiderId);
        EkGiderler GetByLastEkGider();
    }
}