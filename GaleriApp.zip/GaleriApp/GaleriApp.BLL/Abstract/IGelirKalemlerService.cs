﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
   public interface IGelirKalemlerService
    {
        List<GelirKalemler> GetAll();
        void Add(GelirKalemler gelirKalem);
        void Update(GelirKalemler gelirKalem);
        void Delete(int gelirKalemId);
        GelirKalemler GetById(int gelirKalemId);
        GelirKalemler GetByKeyIdAndOlusturanId(int keyId, int olusturanId);
        List<GelirKalemler> GetByKeyIdAndOlusturanIdList(int keyId, int olusturanId);
    }
}
