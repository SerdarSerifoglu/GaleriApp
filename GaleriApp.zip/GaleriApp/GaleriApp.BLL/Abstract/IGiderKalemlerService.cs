﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
   public interface IGiderKalemlerService
    {
        List<GiderKalemler> GetAll();
        void Add(GiderKalemler giderKalem);
        void Update(GiderKalemler giderKalem);
        void Delete(int giderKalemId);
        GiderKalemler GetById(int giderKalemId);
        GiderKalemler GetByKeyIdAndOlusturanId(int keyId, int olusturanId);
        List<GiderKalemler> GetByKeyIdAndOlusturanIdList(int keyId, int olusturanId);
    }
}
