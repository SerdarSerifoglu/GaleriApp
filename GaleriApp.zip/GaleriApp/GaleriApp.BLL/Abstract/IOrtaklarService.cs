﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.BLL.Abstract
{
    
    public interface IOrtaklarService
    {
        List<Ortaklar> GetAll();
        void Add(Ortaklar ortak);
        void Update(Ortaklar ortak);
        void Delete(int ortakId);
        Ortaklar GetById(int ortakId);
        List<Ortaklar> TestSP();
        List<Ortaklar> GetByCariID(int id);
        List<Ortaklar> GetByCariIDor1(int id);
    }
}
