﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.BLL.Abstract
{
    public interface IStaticDetaylarService
    {
        List<StaticDetaylar> GetAll();
        void Add(StaticDetaylar staticDetaylar);
        void Update(StaticDetaylar staticDetaylar);
        void Delete(int staticDetaylarId);
        StaticDetaylar GetById(int staticDetaylarId);
        List<StaticDetaylar> GetByTanimId(int staticTanimId);
        /// <summary>
        /// Eklenen statik detaydaki isim mevcut kayıtlar arasında var mı kontrol ediyor.(Kendi kaydına bakmaması için id gönderdik.)
        /// </summary>
        /// <param name="name">Aranılacak isim</param>
        /// <param name="id">Static Detay Id</param>
        /// <returns></returns>
        List<StaticDetaylar> IsThere(string name, int id, int tanimId);
    }
}
