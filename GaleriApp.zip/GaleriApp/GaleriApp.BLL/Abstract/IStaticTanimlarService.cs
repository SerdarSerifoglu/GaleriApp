﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Abstract
{
    public interface IStaticTanimlarService
    {
        List<StaticTanimlar> GetAll();
        void Add(StaticTanimlar staticTanimlar);
        void Update(StaticTanimlar staticTanimlar);
        void Delete(int staticTanimlarId);
        StaticTanimlar GetById(int staticTanimlarId);
    }
}
