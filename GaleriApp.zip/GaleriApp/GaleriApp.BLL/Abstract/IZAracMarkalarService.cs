﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Abstract
{
    
    public interface IZAracMarkalarService
    {
        List<ZAracMarkalar> GetAll();
        /// <summary>
        /// Mevcut markalar arasında bu kayıt var mı diye kontrol ediyor
        /// </summary>
        /// <param name="name">Kontrol edilecek Marka Ad</param>
        /// <param name="id">Kendi kaydına düzenlerken bakmasın diye gönderilen MarkaId</param>
        /// <returns></returns>
        List<ZAracMarkalar> IsThere(string name, int id);
        void Add(ZAracMarkalar zAracMarka);
        void Update(ZAracMarkalar zAracMarka);
        void Delete(int zAracMarkaId);
        ZAracMarkalar GetById(int zAracMarkaId);
    }
}
