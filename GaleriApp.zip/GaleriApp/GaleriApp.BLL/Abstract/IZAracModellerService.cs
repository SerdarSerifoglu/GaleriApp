﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Abstract
{
    
    public interface IZAracModellerService
    {
        List<ZAracModeller> GetAll();
        void Add(ZAracModeller zAracModel);
        void Update(ZAracModeller zAracModel);
        void Delete(int zAracModelId);
        ZAracModeller GetById(int zAracModelId);
        List<ZAracModeller> GetByMarkaID(int markaID);
        /// <summary>
        /// Model eklerken kayıtlı modeller arasında aynı isimli model var mı diye bakıyor.
        /// </summary>
        /// <param name="modelAd">Aranılacak Model Ad</param>
        /// <param name="markaId">Hangi markanın modellerine bakılacak. Marka Id</param>
        /// <param name="id">Düzenleme yaparken kendi kaydını kontrol etmesin diye gönderildi. Model Id</param>
        /// <returns></returns>
        List<ZAracModeller> IsThere(string modelAd, int markaId, int id);
    }
}
