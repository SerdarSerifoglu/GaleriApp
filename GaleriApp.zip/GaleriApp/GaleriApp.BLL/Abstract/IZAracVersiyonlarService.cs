﻿using GaleriApp.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Abstract
{
    
    public interface IZAracVersiyonlarService
    {
        List<ZAracVersiyon> GetAll();
        void Add(ZAracVersiyon zAracVersiyon);
        void Update(ZAracVersiyon zAracVersiyon);
        void Delete(int zAracVersiyonId);
        ZAracVersiyon GetById(int zAracVersiyonId);
        List<ZAracVersiyon> GetByModelID(int modelID);
        /// <summary>
        /// Versiyon eklerken kayıtlı versiyonlar arasında aynı isimli versiyon var mı diye bakıyor.
        /// </summary>
        /// <param name="versiyonAd">Aranılacak Versiyon Ad</param>
        /// <param name="modelId">Hangi modelin versiyonlarına bakılacak. Model Id</param>
        /// <param name="id">Düzenleme yaparken kendi kaydını kontrol etmesin diye gönderildi. Versiyon Id</param>
        /// <returns></returns>
        List<ZAracVersiyon> IsThere(string versiyonAd, int modelId, int id);
    }
}
