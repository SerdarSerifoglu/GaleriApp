﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public partial class AracGiderlerManager : IAracGiderlerService
    {
        private readonly IAracGiderlerDal _aracGiderlerDal;
        public AracGiderlerManager(IAracGiderlerDal aracGiderlerDal)
        {
            _aracGiderlerDal = aracGiderlerDal;
        }

        public List<AracGiderler> GetAll()
        {
            return _aracGiderlerDal.GetList(x => x.Aktif == true);
        }

        public List<AracGiderler> GetByAracID(int aracId)
        {
            return _aracGiderlerDal.GetList(x => x.AracId == aracId && x.Aktif == true);
        }

        public decimal GetByAracIDToplamGider(int aracId)
        {
            return _aracGiderlerDal.GetList(x => x.AracId == aracId && x.Aktif == true).Select(x => x.Tutar ?? 0).Sum();
        }

        public AracGiderler GetById(int aracGiderId)
        {
            return _aracGiderlerDal.Get(p => p.Id == aracGiderId && p.Aktif == true);
        }

        public void Add(AracGiderler aracGider)
        {
            _aracGiderlerDal.Add(aracGider);
        }

        public void Update(AracGiderler aracGider)
        {
            _aracGiderlerDal.Update(aracGider);
        }

        public void Delete(int aracGiderId)
        {
            _aracGiderlerDal.Delete(new AracGiderler() { Id = aracGiderId });
        }
        
        public int AracGiderOlustur(AracGiderViewModel model)
        {
            var data = _aracGiderlerDal.AracGiderOlustur(model);
            return data;
        }
    }
}
