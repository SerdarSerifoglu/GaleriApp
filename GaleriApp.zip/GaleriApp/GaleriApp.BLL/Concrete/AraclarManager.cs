﻿using System.Collections.Generic;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;

namespace GaleriApp.BLL.Concrete
{

    public class AraclarManager : IAraclarService
    {
        private readonly IAraclarDal _araclarDal;
        public AraclarManager(IAraclarDal araclarDal)
        {
            _araclarDal = araclarDal;
        }

        public List<Araclar> GetAll()
        {
            return _araclarDal.GetList(x => x.Aktif == true);
        }

        public Araclar GetById(int aracId)
        {
            return _araclarDal.Get(p => p.Id == aracId && p.Aktif == true);
        }

        public void Add(Araclar arac)
        {
            _araclarDal.Add(arac);
        }

        public void Update(Araclar arac)
        {
            _araclarDal.Update(arac);
        }

        public void Delete(int aracId)
        {
            _araclarDal.Delete(new Araclar() { Id = aracId });
        }
    }


}
