﻿using GaleriApp.BLL.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class BorcOdemelerManager : IBorcOdemelerService
    {
        private readonly IBorcOdemelerDal _borcOdemelerDal;
        public BorcOdemelerManager(IBorcOdemelerDal borcOdemelerDal)
        {
            _borcOdemelerDal = borcOdemelerDal;
        }

        public List<BorcOdemeler> GetAll()
        {
            return _borcOdemelerDal.GetList(x => x.Aktif == true);
        }

        public List<BorcOdemeler> GetByBorcIdList(int borcId)
        {
            return _borcOdemelerDal.GetList(x => x.BorcId == borcId && x.Aktif == true);
        }

        public BorcOdemeler GetById(int borcOdemeId)
        {
            return _borcOdemelerDal.Get(p => p.Id == borcOdemeId && p.Aktif == true);
        }

        public BorcOdemeler GetByBorcId(int borcId)
        {
            return _borcOdemelerDal.Get(p => p.BorcId == borcId && p.Aktif == true);
        }

        public BorcOdemeler GetByLastBorcOdemeInThisBorc(int borcId)
        {
            return _borcOdemelerDal.GetList(x => x.BorcId == borcId && x.Aktif == true).OrderByDescending(p => p.Id).FirstOrDefault();
        }

        public void Add(BorcOdemeler borcOdeme)
        {
            _borcOdemelerDal.Add(borcOdeme);
        }

        public void Update(BorcOdemeler borcOdeme)
        {
            _borcOdemelerDal.Update(borcOdeme);
        }

        public void Delete(int borcOdemeId)
        {
            _borcOdemelerDal.Delete(new BorcOdemeler() { Id = borcOdemeId });
        }
    }
}
