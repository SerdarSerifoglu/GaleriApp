﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class BorclarManager : IBorclarService
    {
        private readonly IBorclarDal _borclarDal;
        public BorclarManager(IBorclarDal borclarDal)
        {
            _borclarDal = borclarDal;
        }

        public List<Borclar> GetAll()
        {
            return _borclarDal.GetList(x => x.Aktif == true);
        }

        public Borclar GetById(int borcId)
        {
            return _borclarDal.Get(p => p.Id == borcId && p.Aktif == true);
        }
        public Borclar GetByLastBorc()
        {
            return _borclarDal.GetList(x => x.Aktif == true).OrderByDescending(p => p.Id).FirstOrDefault();
        }

        public void Add(Borclar borc)
        {
            _borclarDal.Add(borc);
        }

        public void Update(Borclar borc)
        {
            _borclarDal.Update(borc);
        }

        public void Delete(int borcId)
        {
            _borclarDal.Delete(new Borclar() { Id = borcId });
        }

        public List<Borclar> TestSP()
        {
            var serdar = _borclarDal.ExecuteStoreProcedure("bm");
            return serdar;

        }

    }
}
