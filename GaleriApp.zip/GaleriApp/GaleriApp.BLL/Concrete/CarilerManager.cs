﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class CarilerManager : ICarilerService
    {
        private readonly ICarilerDal _carilerDal;
        public CarilerManager(ICarilerDal carilerDal)
        {
            _carilerDal = carilerDal;
        }

        public List<Cariler> GetAll()
        {
            return _carilerDal.GetList(x => x.Aktif == true);
        }

        public Cariler GetById(int cariId)
        {
            return _carilerDal.Get(p => p.Id == cariId && p.Aktif == true);
        }

        public List<Cariler> GetNotIncludeId(int id)
        {
            return _carilerDal.GetList(x => x.Id != id && x.Aktif == true);
        }

        public List<Cariler> GetbyCariTip(int id)
        {
            return _carilerDal.GetList(x => x.CariTipId == id && x.Aktif == true);
        }

        public void Add(Cariler cari)
        {
            _carilerDal.Add(cari);
        }

        public void Update(Cariler cari)
        {
            _carilerDal.Update(cari);
        }

        public void Delete(int cariId)
        {
            _carilerDal.Delete(new Cariler() { Id = cariId });
        }
    }
}
