﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class EkGelirlerManager : IEkGelirlerService
    {
        private readonly IEkGelirlerDal _ekGelirlerDal;
        public EkGelirlerManager(IEkGelirlerDal ekGelirlerDal)
        {
            _ekGelirlerDal = ekGelirlerDal;
        }

        public List<EkGelirler> GetAll()
        {
            return _ekGelirlerDal.GetList(x => x.Aktif == true);
        }

        public EkGelirler GetById(int ekGelirId)
        {
            return _ekGelirlerDal.Get(p => p.Id == ekGelirId && p.Aktif == true);
        }

        public EkGelirler GetByLastEkGelir()
        {
            return _ekGelirlerDal.GetList(x => x.Aktif == true).OrderByDescending(a => a.Id).FirstOrDefault();
        }

        public void Add(EkGelirler ekGelir)
        {
            _ekGelirlerDal.Add(ekGelir);
        }

        public void Update(EkGelirler ekGelir)
        {
            _ekGelirlerDal.Update(ekGelir);
        }

        public void Delete(int ekGelirId)
        {
            _ekGelirlerDal.Delete(new EkGelirler() { Id = ekGelirId });
        }
    }
}
