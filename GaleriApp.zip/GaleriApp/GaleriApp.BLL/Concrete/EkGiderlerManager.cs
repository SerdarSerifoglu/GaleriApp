﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class EkGiderlerManager : IEkGiderlerService
    {
        private readonly IEkGiderlerDal _ekGiderlerDal;
        public EkGiderlerManager(IEkGiderlerDal ekGiderlerDal)
        {
            _ekGiderlerDal = ekGiderlerDal;
        }

        public List<EkGiderler> GetAll()
        {
            return _ekGiderlerDal.GetList(x => x.Aktif == true);
        }

        public EkGiderler GetById(int ekGiderId)
        {
            return _ekGiderlerDal.Get(p => p.Id == ekGiderId && p.Aktif == true);
        }

        public EkGiderler GetByLastEkGider()
        {
            return _ekGiderlerDal.GetList(x => x.Aktif == true).OrderByDescending(a => a.Id).FirstOrDefault();
        }

        public void Add(EkGiderler ekGider)
        {
            _ekGiderlerDal.Add(ekGider);
        }

        public void Update(EkGiderler ekGider)
        {
            _ekGiderlerDal.Update(ekGider);
        }

        public void Delete(int ekGiderId)
        {
            _ekGiderlerDal.Delete(new EkGiderler() { Id = ekGiderId });
        }
    }
}
