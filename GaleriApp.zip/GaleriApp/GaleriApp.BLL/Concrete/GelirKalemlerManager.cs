﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class GelirKalemlerManager : IGelirKalemlerService
    {
        private readonly IGelirKalemlerDal _gelirKalemlerDal;
        public GelirKalemlerManager(IGelirKalemlerDal gelirKalemlerDal)
        {
            _gelirKalemlerDal = gelirKalemlerDal;
        }

        public List<GelirKalemler> GetAll()
        {
            return _gelirKalemlerDal.GetList(x => x.Aktif == true);
        }

        public GelirKalemler GetById(int gelirKalemId)
        {
            return _gelirKalemlerDal.Get(p => p.Id == gelirKalemId && p.Aktif == true);
        }

        public GelirKalemler GetByKeyIdAndOlusturanId(int keyId, int olusturanId)
        {
            return _gelirKalemlerDal.Get(x => x.KeyId == keyId && x.OlusturanId == olusturanId && x.Aktif == true);
        }

        public List<GelirKalemler> GetByKeyIdAndOlusturanIdList(int keyId, int olusturanId)
        {
            return _gelirKalemlerDal.GetList(x => x.KeyId == keyId && x.OlusturanId == olusturanId && x.Aktif == true);
        }

        public void Add(GelirKalemler gelirKalem)
        {
            _gelirKalemlerDal.Add(gelirKalem);
        }

        public void Update(GelirKalemler gelirKalem)
        {
            _gelirKalemlerDal.Update(gelirKalem);
        }

        public void Delete(int gelirKalemId)
        {
            _gelirKalemlerDal.Delete(new GelirKalemler() { Id = gelirKalemId });
        }
    }
}
