﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class GiderKalemlerManager : IGiderKalemlerService
    {
        private readonly IGiderKalemlerDal _giderKalemlerDal;
        public GiderKalemlerManager(IGiderKalemlerDal giderKalemlerDal)
        {
            _giderKalemlerDal = giderKalemlerDal;
        }

        public List<GiderKalemler> GetAll()
        {
            return _giderKalemlerDal.GetList(x => x.Aktif == true);
        }

        public GiderKalemler GetById(int giderKalemId)
        {
            return _giderKalemlerDal.Get(p => p.Id == giderKalemId && p.Aktif == true);
        }

        public GiderKalemler GetByKeyIdAndOlusturanId(int keyId, int olusturanId)
        {
            return _giderKalemlerDal.Get(x => x.KeyId == keyId && x.OlusturanId == olusturanId && x.Aktif == true);
        }

        public List<GiderKalemler> GetByKeyIdAndOlusturanIdList(int keyId, int olusturanId)
        {
            return _giderKalemlerDal.GetList(x => x.KeyId == keyId && x.OlusturanId == olusturanId && x.Aktif == true);
        }

        public void Add(GiderKalemler giderKalem)
        {
            _giderKalemlerDal.Add(giderKalem);
        }

        public void Update(GiderKalemler giderKalem)
        {
            _giderKalemlerDal.Update(giderKalem);
        }

        public void Delete(int giderKalemId)
        {
            _giderKalemlerDal.Delete(new GiderKalemler() { Id = giderKalemId });
        }
    }
}
