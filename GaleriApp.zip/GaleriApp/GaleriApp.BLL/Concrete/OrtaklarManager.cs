﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class OrtaklarManager : IOrtaklarService
    {
        private readonly IOrtaklarDal _ortaklarDal;
        public OrtaklarManager(IOrtaklarDal ortaklarDal)
        {
            _ortaklarDal = ortaklarDal;
        }

        public List<Ortaklar> GetAll()
        {
            return _ortaklarDal.GetList();
        }

        public Ortaklar GetById(int ortakId)
        {
            return _ortaklarDal.Get(p => p.Id == ortakId);
        }

        public List<Ortaklar> GetByCariID(int id)
        {
            return _ortaklarDal.GetList(x=>x.CariId == id);
        }

        public List<Ortaklar> GetByCariIDor1(int id)
        {
            return _ortaklarDal.GetList(x => x.CariId == id || x.CariId == 1).OrderBy(x=>x.CariId).ToList();
        }

        public void Add(Ortaklar ortak)
        {
            _ortaklarDal.Add(ortak);
        }

        public void Update(Ortaklar ortak)
        {
            _ortaklarDal.Update(ortak);
        }

        public void Delete(int ortakId)
        {
            _ortaklarDal.Delete(new Ortaklar() { Id = ortakId });
        }

        public List<Ortaklar> TestSP()
        {
            var serdar = _ortaklarDal.ExecuteStoreProcedure("bm");
            return serdar;

        }
        
    }
    
}
