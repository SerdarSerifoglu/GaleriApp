﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;

namespace GaleriApp.BLL.Concrete
{
    public class SprocRepository : ISprocRepository
    {
        private readonly SpIcinDbContext _dbContext;
        public SprocRepository(SpIcinDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public DbCommand GetStoredProcedure(
            string name,
            params (string, object)[] nameValueParams)
        {
            return _dbContext
                .LoadStoredProcedure(name)
                .WithSqlParams(nameValueParams);
        }
        public DbCommand GetStoredProcedure(string name)
        {
            return _dbContext.LoadStoredProcedure(name);
        }


    }
}
