﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class StaticDetaylarManager : IStaticDetaylarService
    {
        private readonly IStaticDetaylarDal _staticDetaylarDal;
        public StaticDetaylarManager(IStaticDetaylarDal staticDetaylarDal)
        {
            _staticDetaylarDal = staticDetaylarDal;
        }

        public List<StaticDetaylar> GetAll()
        {
            return _staticDetaylarDal.GetList(x => x.Aktif == true);
        }

        public List<StaticDetaylar> GetByTanimId(int staticTanimId)
        {
            return _staticDetaylarDal.GetListOrderBy(false,a=>a.SiraNo,x => x.TanimId == staticTanimId && x.Aktif == true);
        }

        public StaticDetaylar GetById(int staticDetayId)
        {
            return _staticDetaylarDal.Get(p => p.Id == staticDetayId && p.Aktif == true);
        }

        public List<StaticDetaylar> IsThere(string name, int id, int tanimId)
        {
            return _staticDetaylarDal.GetList(x => x.Id != id && x.StaticDetayAd.ToLower().Trim() == name.ToLower().Trim() && x.Aktif == true && x.TanimId == tanimId);
        }

        public void Add(StaticDetaylar staticDetay)
        {
            _staticDetaylarDal.Add(staticDetay);
        }

        public void Update(StaticDetaylar staticDetay)
        {
            _staticDetaylarDal.Update(staticDetay);
        }

        public void Delete(int staticDetayId)
        {
            _staticDetaylarDal.Delete(new StaticDetaylar() { Id = staticDetayId });
        }
    }
}
