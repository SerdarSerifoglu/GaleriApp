﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.BLL.Concrete
{
    public class StaticTanimlarManager : IStaticTanimlarService
    {
        private readonly IStaticTanimlarDal _staticTanimlarDal;
        public StaticTanimlarManager(IStaticTanimlarDal staticTanimlarDal)
        {
            _staticTanimlarDal = staticTanimlarDal;
        }

        public List<StaticTanimlar> GetAll()
        {
            return _staticTanimlarDal.GetList(x => x.Aktif == true && x.Sabit != true);
        }

        public StaticTanimlar GetById(int staticTanimId)
        {
            return _staticTanimlarDal.Get(p => p.Id == staticTanimId && p.Aktif == true);
        }

        public void Add(StaticTanimlar staticTanim)
        {
            _staticTanimlarDal.Add(staticTanim);
        }

        public void Update(StaticTanimlar staticTanim)
        {
            _staticTanimlarDal.Update(staticTanim);
        }

        public void Delete(int staticTanimId)
        {
            _staticTanimlarDal.Delete(new StaticTanimlar() { Id = staticTanimId });
        }
    }
}
