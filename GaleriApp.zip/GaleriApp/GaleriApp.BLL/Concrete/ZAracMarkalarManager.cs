﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Concrete
{
    public class ZAracMarkalarManager : IZAracMarkalarService
    {
        private readonly IZAracMarkalarDal _zAracMarkalarDal;
        public ZAracMarkalarManager(IZAracMarkalarDal zAracMarkalarDal)
        {
            _zAracMarkalarDal = zAracMarkalarDal;
        }

        public List<ZAracMarkalar> GetAll()
        {
            return _zAracMarkalarDal.GetList(x => x.Aktif == true);
        }

        public ZAracMarkalar GetById(int zAracMarkaId)
        {
            return _zAracMarkalarDal.Get(p => p.Id == zAracMarkaId && p.Aktif == true);
        }

        public List<ZAracMarkalar> IsThere(string name, int id)
        {
            return _zAracMarkalarDal.GetList(x => x.Id != id && x.MarkaAd.ToLower().Trim() == name.ToLower().Trim() && x.Aktif == true);
        }

        public void Add(ZAracMarkalar zAracMarka)
        {
            _zAracMarkalarDal.Add(zAracMarka);
        }

        public void Update(ZAracMarkalar zAracMarka)
        {
            _zAracMarkalarDal.Update(zAracMarka);
        }

        public void Delete(int zAracMarkaId)
        {
            _zAracMarkalarDal.Delete(new ZAracMarkalar() { Id = zAracMarkaId });
        }
    }
}
