﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Concrete
{
    public class ZAracModellerManager : IZAracModellerService
    {
        private readonly IZAracModellerDal _zAracModellerDal;
        public ZAracModellerManager(IZAracModellerDal zAracModellerDal)
        {
            _zAracModellerDal = zAracModellerDal;
        }

        public List<ZAracModeller> GetAll()
        {
            return _zAracModellerDal.GetList(x => x.Aktif == true);
        }

        public ZAracModeller GetById(int zAracModelId)
        {
            return _zAracModellerDal.Get(p => p.Id == zAracModelId && p.Aktif == true);
        }

        public List<ZAracModeller> GetByMarkaID(int markaID = 0)
        {
            return _zAracModellerDal.GetList(x => x.MarkaId == markaID && x.Aktif == true);
        }

        public List<ZAracModeller> IsThere(string modelAd, int markaId, int id)
        {
            return _zAracModellerDal.GetList(x => x.MarkaId == markaId && x.Id != id && x.ModelAd.ToLower().Trim() == modelAd.ToLower().Trim() && x.Aktif == true);
        }

        public void Add(ZAracModeller zAracModel)
        {
            _zAracModellerDal.Add(zAracModel);
        }

        public void Update(ZAracModeller zAracModel)
        {
            _zAracModellerDal.Update(zAracModel);
        }

        public void Delete(int zAracModelId)
        {
            _zAracModellerDal.Delete(new ZAracModeller() { Id = zAracModelId });
        }
    }
}
