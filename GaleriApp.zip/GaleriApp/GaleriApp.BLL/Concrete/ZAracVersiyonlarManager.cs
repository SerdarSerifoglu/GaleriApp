﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.BLL.Concrete
{
    public class ZAracVersiyonlarManager : IZAracVersiyonlarService
    {
        private readonly IZAracVersiyonlarDal _zAracVersiyonlarDal;
        public ZAracVersiyonlarManager(IZAracVersiyonlarDal zAracVersiyonlarDal)
        {
            _zAracVersiyonlarDal = zAracVersiyonlarDal;
        }

        public List<ZAracVersiyon> GetAll()
        {
            return _zAracVersiyonlarDal.GetList(x => x.Aktif == true);
        }

        public ZAracVersiyon GetById(int zAracModelId)
        {
            return _zAracVersiyonlarDal.Get(p => p.Id == zAracModelId && p.Aktif == true);
        }

        public List<ZAracVersiyon> GetByModelID(int modelID = 0)
        {
            return _zAracVersiyonlarDal.GetList(x => x.ModelId == modelID && x.Aktif == true);
        }

        public List<ZAracVersiyon> IsThere(string versiyonAd, int modelId, int id)
        {
            return _zAracVersiyonlarDal.GetList(x => x.ModelId == modelId && x.Id != id && x.VersiyonAd.ToLower().Trim() == versiyonAd.ToLower().Trim() && x.Aktif == true);
        }

        public void Add(ZAracVersiyon zAracVersiyon)
        {
            _zAracVersiyonlarDal.Add(zAracVersiyon);
        }

        public void Update(ZAracVersiyon zAracVersiyon)
        {
            _zAracVersiyonlarDal.Update(zAracVersiyon);
        }

        public void Delete(int zAracVersiyonId)
        {
            _zAracVersiyonlarDal.Delete(new ZAracVersiyon() { Id = zAracVersiyonId });
        }
    }
}
