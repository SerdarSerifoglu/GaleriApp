﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using GaleriApp.Core.Entities;

namespace GaleriApp.Core.DAL
{
    public interface IEntityRepository<T> where T : class, IEntity, new()
    {
        T Get(Expression<Func<T, bool>> filter = null);
        List<T> GetList(Expression<Func<T, bool>> filter = null);
        List<T> GetListOrderBy(bool desc, Expression<Func<T, Object>> orderBy , Expression<Func<T, bool>> filter = null);
        void Add(T entity);
        void Update(T entity);
        void Delete(T entity);
        List<T> ExecuteStoreProcedure(string ad);
    }
}