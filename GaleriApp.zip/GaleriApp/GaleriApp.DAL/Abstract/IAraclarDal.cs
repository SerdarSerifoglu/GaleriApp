﻿using System.Collections.Generic;
using GaleriApp.Core.DAL;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;

namespace GaleriApp.DAL.Abstract
{
    public interface IAraclarDal : IEntityRepository<Araclar>
    {
    }
}