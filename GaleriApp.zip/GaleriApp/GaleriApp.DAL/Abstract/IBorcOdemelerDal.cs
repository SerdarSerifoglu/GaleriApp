﻿using GaleriApp.Core.DAL;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Abstract
{
    public interface IBorcOdemelerDal : IEntityRepository<BorcOdemeler>
    {
    }
}