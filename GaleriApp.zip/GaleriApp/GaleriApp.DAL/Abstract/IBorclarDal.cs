﻿using GaleriApp.Core.DAL;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Abstract
{
    public interface IBorclarDal : IEntityRepository<Borclar>
    {
    }
}