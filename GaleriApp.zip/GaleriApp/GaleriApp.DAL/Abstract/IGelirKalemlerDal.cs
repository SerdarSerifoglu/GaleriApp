﻿using GaleriApp.Core.DAL;
using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Abstract
{
   public interface IGelirKalemlerDal : IEntityRepository<GelirKalemler>
    {
    }
}
