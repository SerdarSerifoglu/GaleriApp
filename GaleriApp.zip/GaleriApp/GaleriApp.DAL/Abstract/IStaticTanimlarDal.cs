﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Core.DAL;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Abstract
{
   public interface IStaticTanimlarDal : IEntityRepository<StaticTanimlar>
    {

    }
}
