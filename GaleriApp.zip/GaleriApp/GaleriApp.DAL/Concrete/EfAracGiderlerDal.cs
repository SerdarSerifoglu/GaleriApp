﻿using GaleriApp.Core.DAL.EntityFramework;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using Microsoft.EntityFrameworkCore;

namespace GaleriApp.DAL.Concrete
{
    public class EfAracGiderlerDal : EfEntityRepositoryBase<AracGiderler, GaleriAppDBContext>, IAracGiderlerDal
    {
        public int AracGiderOlustur(AracGiderViewModel model)
        {
            using (var context = new GaleriAppDBContext())
            {
                var entity = context.Database.ExecuteSqlCommand("sp_AracGideri_Olustur {0},{1},{2},{3},{4},{5}",
                    model.OrtakId1,
                    model.OrtakOran1,
                    model.OrtakId2,
                    model.OrtakOran2,
                    model.AracGider.Tutar,
                    model.AracGider.Id);
                return entity;
            }
        }
    }
}