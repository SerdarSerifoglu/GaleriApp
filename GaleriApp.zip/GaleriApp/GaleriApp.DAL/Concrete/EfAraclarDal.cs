﻿using System.Collections.Generic;
using System.Linq;
using GaleriApp.Core.DAL.EntityFramework;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace GaleriApp.DAL.Concrete
{
    public class EfAraclarDal : EfEntityRepositoryBase<Araclar, GaleriAppDBContext>, IAraclarDal
    {
    }
}