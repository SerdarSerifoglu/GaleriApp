﻿using GaleriApp.Core.DAL.EntityFramework;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Concrete
{
    public class EfBorcOdemelerDal : EfEntityRepositoryBase<BorcOdemeler, GaleriAppDBContext>, IBorcOdemelerDal
    {
    }
}