﻿using System;
using System.Collections.Generic;
using System.Text;
using GaleriApp.Core.DAL.EntityFramework;
using GaleriApp.DAL.Abstract;
using GaleriApp.Entity.Models;

namespace GaleriApp.DAL.Concrete
{
    public class EfZAracMarkalarDal : EfEntityRepositoryBase<ZAracMarkalar, GaleriAppDBContext>, IZAracMarkalarDal
    {
    }
}
