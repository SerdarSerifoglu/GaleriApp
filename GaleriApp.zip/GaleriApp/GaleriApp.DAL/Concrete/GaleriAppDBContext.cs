﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GaleriApp.DAL.Concrete
{
    public partial class GaleriAppDBContext : DbContext
    {
        public GaleriAppDBContext()
        {
        }

        public GaleriAppDBContext(DbContextOptions<GaleriAppDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AracGiderler> AracGiderler { get; set; }
        public virtual DbSet<Araclar> Araclar { get; set; }
        public virtual DbSet<BorcOdemeler> BorcOdemeler { get; set; }
        public virtual DbSet<Borclar> Borclar { get; set; }
		public virtual DbSet<Cariler> Cariler { get; set; }
        public virtual DbSet<EkGelirler> EkGelirler { get; set; }
        public virtual DbSet<EkGiderler> EkGiderler { get; set; }
        public virtual DbSet<GelirKalemler> GelirKalemler { get; set; }
        public virtual DbSet<GiderKalemler> GiderKalemler { get; set; }
        public virtual DbSet<Ortaklar> Ortaklar { get; set; }
		public virtual DbSet<StaticDetaylar> StaticDetaylar { get; set; }
        public virtual DbSet<StaticTanimlar> StaticTanimlar { get; set; }
        public virtual DbSet<ZAracMarkalar> ZAracMarkalar { get; set; }
        public virtual DbSet<ZAracModeller> ZAracModeller { get; set; }
        public virtual DbSet<ZAracVersiyon> ZAracVersiyon { get; set; }
        

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DESKTOP-RHAN2O7;Database=GaleriAppDB;User ID=serdar2;Password=Serdar1903;");
                //optionsBuilder.UseSqlServer("Server=.\\MSSQLSERVER2016;Database=konuralp_tk;User ID=serdar;Password=&Ll9t4l0;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<AracGiderler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Aciklama).HasMaxLength(500);

                entity.Property(e => e.AracId).HasColumnName("AracID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.IslemId).HasColumnName("IslemID");

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)").HasColumnName("Tutar");
                
            });

            modelBuilder.Entity<Araclar>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Aciklama).HasMaxLength(500);

                entity.Property(e => e.AlinanKisi).HasMaxLength(50);

                entity.Property(e => e.AlinanKisiTel).HasMaxLength(50);

                entity.Property(e => e.AlisFiyati).HasColumnType("decimal(18, 2)");
				
				entity.Property(e => e.AlisTarihi).HasColumnType("datetime");

                entity.Property(e => e.AracPlaka).HasMaxLength(15);

                entity.Property(e => e.AracYeniPlaka).HasMaxLength(15);

                entity.Property(e => e.MuayeneTarihi).HasColumnType("datetime");

                entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.DurumId).HasColumnName("DurumID");

                entity.Property(e => e.MarkaId).HasColumnName("MarkaID");

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.ModelId).HasColumnName("ModelID");

                entity.Property(e => e.Renk).HasMaxLength(15);

                entity.Property(e => e.SatilanKisi).HasMaxLength(50);

                entity.Property(e => e.SatilanKisiTel).HasMaxLength(50);

                entity.Property(e => e.SatisFiyati).HasColumnType("decimal(18, 2)");
				
				entity.Property(e => e.SatisTarihi).HasColumnType("datetime");

                entity.Property(e => e.VersiyonId).HasColumnName("VersiyonID");
            });

            modelBuilder.Entity<BorcOdemeler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BorcId).HasColumnName("BorcID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.OdenenTutar).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.OdemeTarihi).HasColumnType("datetime");

            });

            modelBuilder.Entity<Borclar>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.DurumId).HasColumnName("DurumID");

                entity.Property(e => e.KalanTutar).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.OdemeTarihi).HasColumnType("datetime");

                entity.Property(e => e.OdenecekTutar).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.OlusturanId).HasColumnName("OlusturanID");

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Aciklama).HasMaxLength(500);
            });

			    modelBuilder.Entity<Cariler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CariAd)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.CariTipId).HasColumnName("CariTipID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);
            });
			
            modelBuilder.Entity<EkGelirler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Aciklama).HasMaxLength(500);
				
				entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.TipId).HasColumnName("TipID");

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<EkGiderler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Aciklama).HasMaxLength(500);

				entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.TipId).HasColumnName("TipID");

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<GelirKalemler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");
				
				entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.KeyId).HasColumnName("KeyID");

                entity.Property(e => e.OlusturanId).HasColumnName("OlusturanID");

                entity.Property(e => e.Oran).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.OrtakId).HasColumnName("OrtakID");

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<GiderKalemler>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");
				
				entity.Property(e => e.CariId).HasColumnName("CariID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.KeyId).HasColumnName("KeyID");

                entity.Property(e => e.OlusturanId).HasColumnName("OlusturanID");

                entity.Property(e => e.Oran).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.OrtakId).HasColumnName("OrtakID");

                entity.Property(e => e.Tutar).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<Ortaklar>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

				 entity.Property(e => e.CariId).HasColumnName("CariID");
                entity.Property(e => e.OrtakAd)
					.IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.OrtakOran).HasColumnType("decimal(18, 0)");
            });
			
			   modelBuilder.Entity<StaticDetaylar>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreDate).HasColumnType("datetime");

                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);
                entity.Property(e => e.StaticDetayAd).HasMaxLength(100);

                entity.Property(e => e.StringValue).HasMaxLength(100);

                entity.Property(e => e.TanimId).HasColumnName("TanimID");
            });

            modelBuilder.Entity<StaticTanimlar>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");
				
				entity.Property(e => e.CreDate).HasColumnType("datetime");
				
                entity.Property(e => e.CreUser).HasMaxLength(50);

                entity.Property(e => e.ModDate).HasColumnType("datetime");

                entity.Property(e => e.ModUser).HasMaxLength(50);

                entity.Property(e => e.StaticTanimAd).HasMaxLength(100);

                entity.Property(e => e.StringValue).HasMaxLength(100);
            });

            modelBuilder.Entity<ZAracMarkalar>(entity =>
            {
                entity.ToTable("zAracMarkalar");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.MarkaAd).HasMaxLength(50);

                entity.Property(e => e.MarkaValue).HasMaxLength(50);
            });

            modelBuilder.Entity<ZAracModeller>(entity =>
            {
                entity.ToTable("zAracModeller");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.MarkaId).HasColumnName("MarkaID");

                entity.Property(e => e.ModelAd).HasMaxLength(100);

                entity.Property(e => e.ModelValue).HasMaxLength(100);
            });

            modelBuilder.Entity<ZAracVersiyon>(entity =>
            {
                entity.ToTable("zAracVersiyon");

                entity.Property(e => e.Id).HasColumnName("ID");
                
                entity.Property(e => e.ModelId).HasColumnName("ModelID");

                entity.Property(e => e.VersiyonAd).HasMaxLength(100);

                entity.Property(e => e.VersiyonValue).HasMaxLength(100);
                
            });
        }
    }
}
