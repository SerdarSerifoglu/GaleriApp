﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace GaleriApp.DAL.Concrete
{
    public class SpIcinDbContext:DbContext
    {
        public SpIcinDbContext(DbContextOptions<SpIcinDbContext> options) : base(options)
        {

        }
    }
}
