﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.Filters
{
   public class AracFilter
    {
        public int? DurumID { get; set; }
        public int? CariID { get; set; }
    }
}
