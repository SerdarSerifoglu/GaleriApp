﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GaleriApp.Entity.Filters
{
   public class RaporFilter
   {
       [Display(Name = "Cari Seç")]
       public int? CariID { get; set; } = 1;
       [Display(Name = "Ortak")]
        public int? OrtakID { get; set; }
       [DataType(DataType.Date)]
       [Display(Name = "Tarih Aralığı")]
        public DateTime? Tarih1 { get; set; }
       [DataType(DataType.Date)]
        public DateTime? Tarih2 { get; set; }
    }
}
