﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.Entity.HelperModels
{
    public class AracGiderViewModel
    {
        public AracGiderler AracGider { get; set; }
        public Araclar Arac { get; set; }
        public int? OrtakId1 { get; set; }
        public decimal? OrtakOran1 { get; set; }
        public int? OrtakId2 { get; set; }
        public decimal? OrtakOran2 { get; set; }
        public int? OrtakId3 { get; set; }
        public decimal? OrtakOran3 { get; set; }
    }
}
