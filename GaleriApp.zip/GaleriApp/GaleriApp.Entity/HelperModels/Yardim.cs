﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.HelperModels
{
    public static class Yardim
    {
        public static string MevcutGelir =
            "Mevcut Gelir: Belirtilen tarih aralığındaki tüm gelirlerin toplamıdır.";

        public static string MevcutGider =
            "Mevcut Gider: Belirtilen tarih aralığındaki tüm giderlerin toplamıdır.";

        public static string SatistakiAraclarinDegeri =
            "Alış tarihi, belirtilen tarih aralıklarında olup, durumu satışta olan tüm araçların Alış Fiyatlarının Toplamıdır";
        public static string SatistakiAraclarinveSponsorlularinDegeri =
            "Alış tarihi, belirtilen tarih aralıklarında olup, durumu satışta olan tüm araçların Alış Fiyatlarının Toplamıdır";

        public static string ToplamBorc = "Belirtilen Tarih Aralığındaki Tüm Borçların Kalan Tutarları Toplamı";
        public static string BorclarHaricFark = "Borçlar Hariç Fark Hesaplaması: Mevcut Gelir - Mevcut Gider";
        public static string BorclarDahilFark = "Borçlar Dahil Fark Hesaplaması: Mevcut Gelir - Mevcut Gider - Borç Miktarı";

    }
}
