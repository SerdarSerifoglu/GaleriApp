﻿using GaleriApp.Core.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GaleriApp.Entity.Models
{
    public partial class AracGiderler : IEntity
    {
        [Display(Name = "KN")]
        public int Id { get; set; }
        [Display(Name = "Araç No")]
        public int AracId { get; set; }
        [Display(Name = "İşlem Tipi")]
        public int? IslemId { get; set; }
        [Required]
        [Display(Name = "Tutar")]
        public decimal? Tutar { get; set; }
        [Display(Name = "Açıklama")]
        public string Aciklama { get; set; }
        public bool? Aktif { get; set; } = true;
        public string CreUser { get; set; }
        public DateTime? CreDate { get; set; }
        [Display(Name = "Değiştiren")]
        public string ModUser { get; set; }
        [Display(Name = "Değiştirme Tarihi")]
        public DateTime? ModDate { get; set; }
    }

    public class AracGiderlerViewDTO : AracGiderler
    {
        [Display(Name = "İşlem")]
        public string IslemAd { get; set; }
    }

}
