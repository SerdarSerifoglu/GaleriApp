﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class Araclar : IEntity
    {
        public Araclar()
        {
            //AracGiderler = new HashSet<AracGiderler>();
        }
        [Display(Name = "Kayıt No")]
        public int Id { get; set; }
        [Display(Name = "Durum")]
        public int? DurumId { get; set; }
        [Display(Name = "Sponsor")]
        public int? CariId { get; set; }
        [Display(Name = "Plaka")]
        public string AracPlaka { get; set; }
        [Display(Name = "Km")]
        public int? AracKm { get; set; }
        [Display(Name = "Marka")]
        public int? MarkaId { get; set; }
        [Display(Name = "Model")]
        public int? ModelId { get; set; }
        [Display(Name = "Versiyon")]
        public int? VersiyonId { get; set; }
        [Display(Name = "Yeni Plaka")]
        public string AracYeniPlaka { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Muayene Tarihi")]
        public DateTime? MuayeneTarihi { get; set; }
        [Display(Name = "Renk")]
        public string Renk { get; set; }
        [Display(Name = "Alınan Kişi")]
        public string AlinanKisi { get; set; }
        [Display(Name = "Alınan Kişi Tel")]
        [DataType(DataType.PhoneNumber)]
        public string AlinanKisiTel { get; set; }
        [Display(Name = "Satılan Kişi")]
        public string SatilanKisi { get; set; }
        [Display(Name = "Satılan Kişi Tel")]
        [DataType(DataType.PhoneNumber)]
        public string SatilanKisiTel { get; set; }
        [Display(Name = "Açıklama")]
        public string Aciklama { get; set; }
        [Display(Name = "Alış Fiyatı")]
        public decimal? AlisFiyati { get; set; }
        [Display(Name = "Alış Tarihi")]
        [DataType(DataType.Date)]
        public DateTime? AlisTarihi { get; set; }
        [Display(Name = "Satış Fiyatı")]
        public decimal? SatisFiyati { get; set; }
        [Display(Name = "Satış Tarihi")]
        [DataType(DataType.Date)]
        public DateTime? SatisTarihi { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        [DataType(DataType.Date)]
        public DateTime? CreDate { get; set; }
        [Display(Name = "Değiştiren")]
        public string ModUser { get; set; }
        [Display(Name = "Değiştirilme Tarihi")]
        [DataType(DataType.Date)]
        public DateTime? ModDate { get; set; }

        //splerin sonuç dönmesinde sıkıntı çıkardığı için kapatıldı
        //public virtual ICollection<AracGiderler> AracGiderler { get; set; }
    }

    public class AraclarViewDTO : Araclar
    {
        [Display(Name = "Durum")]
        public string DurumAd { get; set; }
        [Display(Name = "Marka")]
        public string MarkaAd { get; set; }
        [Display(Name = "Model")]
        public string ModelAd { get; set; }
        [Display(Name = "Versiyon")]
        public string VersiyonAd { get; set; }
        [Display(Name = "Cari")]
        public string CariAd { get; set; }
    }
}
