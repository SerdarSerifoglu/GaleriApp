﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace GaleriApp.Entity.Models
{
    public class BaseOrtak
    {
        [NotMapped]
        [Required]
        public int KeyModalId { get; set; }
        [NotMapped]
        [Required]
        public int? OrtakId1 { get; set; }
        [NotMapped]
        [Required]
        public decimal? OrtakOran1 { get; set; }
        [NotMapped]
        [Required]
        public int? OrtakId2 { get; set; }
        [NotMapped]
        [Required]
        public decimal? OrtakOran2 { get; set; }
        public int? OrtakId3 { get; set; }
        public decimal? OrtakOran3 { get; set; }

    }
}
