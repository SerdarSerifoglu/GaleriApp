﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class BorcOdemeler : IEntity
    {
        [Display(Name = "K.N.")]
        public int Id { get; set; }
        [Display(Name = "Borç No")]
        public int? BorcId { get; set; }
        [Display(Name = "Ödenen Tutar")]
        public decimal? OdenenTutar { get; set; }
        [Display(Name = "Ödeme Tarihi")]
        [DataType(DataType.Date)]
        public DateTime? OdemeTarihi { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        public DateTime? CreDate { get; set; }
    }
}
