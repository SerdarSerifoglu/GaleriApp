﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class Borclar : IEntity
    {
        [Display(Name = "K.N.")]
        public int Id { get; set; }
        public int? OlusturanId { get; set; }
        [Display(Name = "Borç Durum")]
        public int? DurumId { get; set; }
        [Display(Name = "Borçlanılan Cari")]
        public int? CariId { get; set; }
        [Display(Name = "Borç Tutarı")]
        public decimal? Tutar { get; set; }
        [Display(Name = "Ödenecek Tutar")]
        public decimal? OdenecekTutar { get; set; }
        [Display(Name = "Kalan Tutar")]
        public decimal? KalanTutar { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Ödeme Tarihi")]
        public DateTime? OdemeTarihi { get; set; }
        [Display(Name = "Açıklama")]
        public string Aciklama { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        public DateTime? CreDate { get; set; }
        [Display(Name = "Değiştiren")]
        public string ModUser { get; set; }
        [Display(Name = "Değiştirilme Tarihi")]
        public DateTime? ModDate { get; set; }
    }

    public class BorclarViewDTO : Borclar
    {
        [Display(Name = "Durum")]
        public string DurumAd { get; set; }
        [Display(Name = "Borçlanılan")]
        public string CariAd { get; set; }
    }
}
