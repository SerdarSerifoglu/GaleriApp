﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class Cariler : IEntity
    {
        [Display(Name = "Kayıt No")]
        public int Id { get; set; }
        [Display(Name = "Cari Ad")]
        public string CariAd { get; set; }
        [Display(Name = "Cari Tip")]
        public int CariTipId { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        public DateTime? CreDate { get; set; }
        [Display(Name = "Değiştiren")]
        public string ModUser { get; set; }
        [Display(Name = "Değiştirilme Tarihi")]
        public DateTime? ModDate { get; set; }
    }

    public class CarilerViewDTO : Cariler
    {
        [Display(Name = "Cari Tip")]
        public string CariTipAd { get; set; }
    }
}
