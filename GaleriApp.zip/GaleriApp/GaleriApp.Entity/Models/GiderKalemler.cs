﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class GiderKalemler : IEntity
    {
        [Display(Name = "K.N.")]
        public int Id { get; set; }
        [Display(Name = "Kaynak No")]
        public int? KeyId { get; set; }
        public int? OlusturanId { get; set; }
		public int? CariId { get; set; }
        public int? OrtakId { get; set; }
        [Display(Name = "Oran")]
        public decimal Oran { get; set; }
        [Display(Name = "Tutar")]
        public decimal Tutar { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        public DateTime? CreDate { get; set; }
    }

    public class GiderKalemlerViewDTO : GiderKalemler
    {
        [Display(Name = "Cari")]
        public string CariAd { get; set; }
        [Display(Name = "Ortak")]
        public string OrtakAd { get; set; }
        [Display(Name = "Oluşturan Sayfa")]
        public string OlusturanAd { get; set; }
    }

    public class GiderKalemlerFilter
    {
        public int? KeyID { get; set; }
        public int? OlusturanID { get; set; }
        public int? OrtakID { get; set; }
    }
}
