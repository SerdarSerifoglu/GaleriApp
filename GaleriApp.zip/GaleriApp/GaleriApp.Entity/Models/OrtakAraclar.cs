﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.Models
{
   public class OrtakAraclar : BaseOrtak
    {
        public decimal? AracAlisFiyati { get; set; }
        public string AracAlinanKisi { get; set; }
        public string AracAlinanKisiTel { get; set; }
        public DateTime? AracAlisTarihi { get; set; }
        public decimal? AracSatisFiyati { get; set; }
        public string AracSatilanKisi { get; set; }
        public string AracSatilanKisiTel { get; set; }
        public DateTime? AracSatisTarihi { get; set; }
    }
}
