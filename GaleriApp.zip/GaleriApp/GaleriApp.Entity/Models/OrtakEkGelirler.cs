﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.Models
{
    public class OrtakEkGelirler : BaseOrtak
    {

    }
}
