﻿using System;
using System.Collections.Generic;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class Ortaklar : IEntity
    {
        public int Id { get; set; }
 		public int CariId { get; set; }
        public string OrtakAd { get; set; }
        public decimal? OrtakOran { get; set; }
		public int? OrtakTip { get; set; }
    }
}
