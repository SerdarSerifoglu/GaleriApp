﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class StaticDetaylar : IEntity
    {
        [Display(Name = "K.N.")]
        public int Id { get; set; }
        [Display(Name = "Sabit Tanım No")]
        public int TanimId { get; set; }
        [Display(Name = "Sabit Detay Ad")]
        public string StaticDetayAd { get; set; }
        [Display(Name = "Sıra No")]
        public int? SiraNo { get; set; }
        [Display(Name = "Sayısal Değer")]
        public int? IntValue { get; set; }
        [Display(Name = "Değer")]
        public string StringValue { get; set; }
        public bool? Aktif { get; set; } = true;
        [Display(Name = "Oluşturan")]
        public string CreUser { get; set; }
        [Display(Name = "Oluşturulma Tarihi")]
        public DateTime? CreDate { get; set; }
        [Display(Name = "Değiştiren")]
        public string ModUser { get; set; }
        [Display(Name = "Değiştirilme Tarihi")]
        public DateTime? ModDate { get; set; }
    }
}
