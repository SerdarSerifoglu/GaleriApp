﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class ZAracModeller : IEntity
    {
        [Display(Name = "K.No")]
        public int Id { get; set; }
        [Display(Name = "Marka No")]
        public int? MarkaId { get; set; }
        [Display(Name = "Model Ad")]
        public string ModelAd { get; set; }
        [Display(Name = "Model Değer")]
        public string ModelValue { get; set; }
        [Display(Name = "Model Değer Sayı")]
        public int? ModelIntValue { get; set; }
        public bool? Aktif { get; set; } = true;
    }
}
