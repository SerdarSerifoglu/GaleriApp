﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using GaleriApp.Core.Entities;

namespace GaleriApp.Entity.Models
{
    public partial class ZAracVersiyon : IEntity
    {
        [Display(Name = "K.No")]
        public int Id { get; set; }
        [Display(Name = "Model No")]
        public int? ModelId { get; set; }
        [Display(Name = "Versiyon Ad")]
        public string VersiyonAd { get; set; }
        [Display(Name = "Versiyon Değer")]
        public string VersiyonValue { get; set; }
        [Display(Name = "Versiyon Sayısal Değer")]
        public int? VersiyonIntValue { get; set; }
        public bool? Aktif { get; set; } = true;
    }
}
