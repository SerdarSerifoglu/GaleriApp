﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.ViewModels
{
   public class RaporBilancoViewModel
    {
        public decimal? Gelir { get; set; }
        public decimal? Gider { get; set; }
        public decimal? BorclarHaricFark { get; set; }
        public decimal? Borc { get; set; }
        public decimal? BorclarDahilFark { get; set; }
        public decimal? SatistakiSirketAraclarininMaliyeti { get; set; }
        public decimal? SatistakiSirketSponsorAraclarininMaliyeti { get; set; }
    }
}
