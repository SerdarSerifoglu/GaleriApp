﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaleriApp.Entity.ViewModels
{
   public class RaporViewModel
    {
        public int? ToplamAracAdet { get; set; }
        public int? YeniAracAdet { get; set; }
        public int? SatistaOlanAracAdet { get; set; }
        public int? SatilanAracAdet { get; set; }
        public int? SponsorluAraclarAdet { get; set; }
    }
}
