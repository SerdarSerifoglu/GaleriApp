﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Filters;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Entities;
using GaleriApp.MVCWebUI.Filters;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Update;
using NonFactors.Mvc.Grid;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    //[HandleException]
    public class AracController : BaseController
    {
        private string ZorunluAlanlarAracEkle = "AracPlaka,AracKm,MarkaId,ModelId,VersiyonId";
        private string ZorunluAlanlarCariAracEkle = "AracPlaka,AracKm,MarkaId,ModelId,VersiyonId,CariId";

        private readonly IAraclarService _araclarService;
        private readonly IAracGiderlerService _aracGiderlerService;
        private readonly IZAracMarkalarService _zAracMarkalarService;
        private readonly IZAracModellerService _zAracModellerService;
        private readonly IZAracVersiyonlarService _zAracVersiyonlarService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly IGiderKalemlerService _giderKalemlerService;
        private readonly IGelirKalemlerService _gelirKalemlerService;
        private readonly ICarilerService _carilerService;
        private readonly ISprocRepository _sprocRepository;
        private UserManager<CustomIdentityUser> _userManager;

        public AracController(
            IAraclarService araclarService,
            IAracGiderlerService aracGiderlerService,
            IZAracMarkalarService zAracMarkalarService,
            IZAracModellerService zAracModellerService,
            IZAracVersiyonlarService zAracVersiyonlarService,
            IStaticDetaylarService staticDetaylarService,
            IGiderKalemlerService giderKalemlerService,
            IGelirKalemlerService gelirKalemlerService,
            ICarilerService carilerService,
            ISprocRepository sprocRepository,
            UserManager<CustomIdentityUser> userManager
            )
        {
            _araclarService = araclarService;
            _aracGiderlerService = aracGiderlerService;
            _zAracMarkalarService = zAracMarkalarService;
            _zAracModellerService = zAracModellerService;
            _zAracVersiyonlarService = zAracVersiyonlarService;
            _staticDetaylarService = staticDetaylarService;
            _giderKalemlerService = giderKalemlerService;
            _gelirKalemlerService = gelirKalemlerService;
            _carilerService = carilerService;
            _sprocRepository = sprocRepository;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        #region Excele Aktarma Grid Örnek Uygulama
        /// <summary>
        /// /Excel Yüklemesi için prototip daha sonra devereye alınabilir
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        //[HttpGet]
        //public ActionResult ExportIndex()
        //{
        //    // Using EPPlus from nuget
        //    using (ExcelPackage package = new ExcelPackage())
        //    {
        //        Int32 row = 2;
        //        Int32 col = 1;

        //        package.Workbook.Worksheets.Add("Data");
        //        IGrid<AraclarViewDTO> grid = CreateExportableGrid();
        //        ExcelWorksheet sheet = package.Workbook.Worksheets["Data"];

        //        foreach (IGridColumn column in grid.Columns)
        //        {
        //            sheet.Cells[1, col].Value = column.Title;
        //            sheet.Column(col++).Width = 18;

        //            column.IsEncoded = false;
        //        }

        //        foreach (IGridRow<AraclarViewDTO> gridRow in grid.Rows)
        //        {
        //            col = 1;
        //            foreach (IGridColumn column in grid.Columns)
        //                sheet.Cells[row, col++].Value = column.ValueFor(gridRow);

        //            row++;
        //        }

        //        return File(package.GetAsByteArray(), "application/unknown", "Export.xlsx");
        //    }
        //}

        //private IGrid<AraclarViewDTO> CreateExportableGrid()
        //{
        //    IGrid<AraclarViewDTO> grid = new Grid<AraclarViewDTO>(_sprocRepository
        //        .GetStoredProcedure("[dbo].[sp_Araclar_TamListe]")
        //        .ExecuteStoredProcedure<AraclarViewDTO>());
        //    grid.ViewContext = new ViewContext { HttpContext = HttpContext };
        //    grid.Query = Request.Query;

        //    grid.Columns.Add(model => model.CariAd).Titled("Name");
        //    grid.Columns.Add(model => model.DurumAd).Titled("Surname");

        //    grid.Columns.Add(model => model.MarkaAd).Titled("Age");
        //    grid.Columns.Add(model => model.ModelAd).Titled("Birthday").Formatted("{0:d}");
        //    grid.Columns.Add(model => model.VersiyonAd).Titled("Employed");

        //    grid.Pager = new GridPager<AraclarViewDTO>(grid);

        //    foreach (IGridColumn column in grid.Columns)
        //    {
        //        column.Filter.IsEnabled = true;
        //        column.Sort.IsEnabled = true;
        //    }

        //    return grid;
        //}

        #endregion
        public IActionResult Liste(AracFilter filter)
        {
            var araclar = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Araclar_TamListe]")
                .WithSqlParams(
                    ("DurumId", filter.DurumID),
                    ("CariId", filter.CariID))
                .ExecuteStoredProcedure<AraclarViewDTO>();

            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(araclar);
        }

        public IActionResult CariAracEkle()
        {
            ViewBag.ZorunluAlanlar = ZorunluAlanlarCariAracEkle;

            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(new Araclar());
        }

        [HttpPost]
        public IActionResult CariAracEkle([FromBody]Araclar model)
        {
            model.DurumId = 1;
            model.CreUser = HttpContext.User.Identity.Name;
            model.ModUser = HttpContext.User.Identity.Name;
            model.CreDate = DateTime.Now;
            model.ModDate = DateTime.Now;
            _araclarService.Add(model);
            TempData["message"] = model.AracPlaka.ToString() + " Plakalı Sponsorlu Araç Kaydedildi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "Arac") });
        }

        public IActionResult Ekle()
        {
            ViewBag.ZorunluAlanlar = ZorunluAlanlarAracEkle;

            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(new Araclar());
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]Araclar model)
        {
            model.DurumId = 1;
            model.CariId = 1;
            model.CreUser = HttpContext.User.Identity.Name;
            model.ModUser = HttpContext.User.Identity.Name;
            model.CreDate = DateTime.Now;
            model.ModDate = DateTime.Now;
            _araclarService.Add(model);
            TempData["message"] = model.AracPlaka.ToString() + " Plakalı Araç Kaydedildi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "Arac") });
        }

        public IActionResult Duzenle(int id)
        {
            var guncellenecekModel = _araclarService.GetById(id);
            var aracGiderleri = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_AracGiderler_TamListe]")
                .WithSqlParams(
                    ("AracId", guncellenecekModel.Id))
                .ExecuteStoredProcedure<AracGiderlerViewDTO>();
            var cari = _carilerService.GetById(guncellenecekModel.CariId??0);
            //rapor düzenlenicek sonradan
            var aracRapor = AracRapor(guncellenecekModel.Id);

            var viewModel = new AraclarViewModel()
            {
                Arac = guncellenecekModel,
                AracGiderler = aracGiderleri,
                CariAd = cari.CariAd,
                AracRapor = aracRapor
            };

            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName + "/" + id;

            ViewBag.ZorunluAlanlar = ZorunluAlanlarAracEkle;
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Duzenle([FromBody]Araclar model)
        {
            var guncellenecek = _araclarService.GetById(model.Id);
            model.DurumId = 1;
            model.ModDate = DateTime.Now;
            model.CreDate = guncellenecek.CreDate;
            model.CreUser = guncellenecek.CreUser;
            _araclarService.Update(model);
            TempData["message"] = model.Id.ToString() + " Kayıt No'lu Araç Düzenlendi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "Arac") });
        }

        public IActionResult AlimiOnayla([FromBody]OrtakAraclar ortakAraclar)
        {
            var arac = _araclarService.GetById(ortakAraclar.KeyModalId);
            arac.DurumId = 2;
            arac.AlisTarihi = ortakAraclar.AracAlisTarihi;
            arac.AlisFiyati = ortakAraclar.AracAlisFiyati;
            arac.AlinanKisi = ortakAraclar.AracAlinanKisi;
            arac.AlinanKisiTel = ortakAraclar.AracAlinanKisiTel;
            _araclarService.Update(arac);

            var giderModel = new GiderKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId1,
                Oran = ortakAraclar.OrtakOran1 ?? 0,
                Tutar = (arac.AlisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel2 = new GiderKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId2,
                Oran = ortakAraclar.OrtakOran2 ?? 0,
                Tutar = (arac.AlisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _giderKalemlerService.Add(giderModel);
            _giderKalemlerService.Add(giderModel2);
            TempData["message"] = arac.Id.ToString() + " Kayıt No'lu Aracın Alımı Onaylandı.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Duzenle", "Arac", new { id = ortakAraclar.KeyModalId }) });
        }

        public IActionResult AracSatis([FromBody]OrtakAraclar ortakAraclar)
        {
            var arac = _araclarService.GetById(ortakAraclar.KeyModalId);
            arac.DurumId = 3;
            arac.SatisTarihi = ortakAraclar.AracSatisTarihi;
            arac.SatisFiyati = ortakAraclar.AracSatisFiyati;
            arac.SatilanKisi = ortakAraclar.AracSatilanKisi;
            arac.SatilanKisiTel = ortakAraclar.AracSatilanKisiTel;
            _araclarService.Update(arac);

            var gelirModel = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId1,
                Oran = ortakAraclar.OrtakOran1 ?? 0,
                Tutar = (arac.SatisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirModel2 = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId2,
                Oran = ortakAraclar.OrtakOran2 ?? 0,
                Tutar = (arac.SatisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _gelirKalemlerService.Add(gelirModel);
            _gelirKalemlerService.Add(gelirModel2);
            TempData["message"] = arac.Id.ToString() + " Kayıt No'lu Aracın Satışı Gerçekleştirildi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Duzenle", "Arac", new { id = ortakAraclar.KeyModalId }) });
        }

        public IActionResult AlimiOnaylaKismiOrtak([FromBody]OrtakAraclar ortakAraclar)
        {
            if (ortakAraclar.OrtakOran1 + ortakAraclar.OrtakOran2 + ortakAraclar.OrtakOran3 != 100)
            {
                return Json("Oranlar 100 olmalı");
            }
            var arac = _araclarService.GetById(ortakAraclar.KeyModalId);
            arac.DurumId = 2;
            arac.AlisTarihi = ortakAraclar.AracAlisTarihi;
            arac.AlisFiyati = ortakAraclar.AracAlisFiyati;
            arac.AlinanKisi = ortakAraclar.AracAlinanKisi;
            arac.AlinanKisiTel = ortakAraclar.AracAlinanKisiTel;
            _araclarService.Update(arac);

            var giderModel = new GiderKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId1,
                Oran = ortakAraclar.OrtakOran1 ?? 0,
                Tutar = (arac.AlisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel2 = new GiderKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId2,
                Oran = ortakAraclar.OrtakOran2 ?? 0,
                Tutar = (arac.AlisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel3 = new GiderKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId3,
                Oran = ortakAraclar.OrtakOran3 ?? 0,
                Tutar = (arac.AlisFiyati ?? 0) * Oran(ortakAraclar.OrtakOran3),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _giderKalemlerService.Add(giderModel);
            _giderKalemlerService.Add(giderModel2);
            _giderKalemlerService.Add(giderModel3);
            TempData["message"] = arac.Id.ToString() + " Kayıt No'lu Sponsorlu Aracın Alımı Onaylandı.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Duzenle", "Arac", new { id = ortakAraclar.KeyModalId }) });
        }

        public IActionResult AracSatisKismiOrtak([FromBody]OrtakAraclar ortakAraclar)
        {
            var arac = _araclarService.GetById(ortakAraclar.KeyModalId);
            arac.DurumId = 3;
            arac.SatisTarihi = ortakAraclar.AracSatisTarihi;
            arac.SatisFiyati = ortakAraclar.AracSatisFiyati;
            arac.SatilanKisi = ortakAraclar.AracSatilanKisi;
            arac.SatilanKisiTel = ortakAraclar.AracSatilanKisiTel;
            _araclarService.Update(arac);

            //Aracın alış fiyatı cariye ödendi
            var gelirMaliyet = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId3,
                Oran = 100,
                Tutar = (arac.AlisFiyati ?? 0),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            //masraflar şirket ortaklarına verildi
            var masraflar = _aracGiderlerService.GetByAracIDToplamGider(arac.Id);
            var gelirMasraf1 = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId1,
                Oran = 50,
                Tutar = masraflar * Oran(50),

                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirMasraf2 = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId2,
                Oran = 50,
                Tutar = masraflar * Oran(50),

                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };


            //Net kar seçilen oranlarda bölüşüldü
            var netKar = arac.SatisFiyati - arac.AlisFiyati - _aracGiderlerService.GetByAracIDToplamGider(arac.Id);

            var gelirModel = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId1,
                Oran = ortakAraclar.OrtakOran1 ?? 0,
                Tutar = (netKar ?? 0) * Oran(ortakAraclar.OrtakOran1),

                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirModel2 = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = 1,
                OrtakId = ortakAraclar.OrtakId2,
                Oran = ortakAraclar.OrtakOran2 ?? 0,
                Tutar = (netKar ?? 0) * Oran(ortakAraclar.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirModel3 = new GelirKalemler()
            {
                KeyId = arac.Id,
                OlusturanId = 1,
                CariId = arac.CariId,
                OrtakId = ortakAraclar.OrtakId3,
                Oran = ortakAraclar.OrtakOran3 ?? 0,
                Tutar = (netKar ?? 0) * Oran(ortakAraclar.OrtakOran3),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            _gelirKalemlerService.Add(gelirMaliyet);
            _gelirKalemlerService.Add(gelirMasraf1);
            _gelirKalemlerService.Add(gelirMasraf2);
            _gelirKalemlerService.Add(gelirModel);
            _gelirKalemlerService.Add(gelirModel2);
            _gelirKalemlerService.Add(gelirModel3);

            TempData["message"] = arac.Id.ToString() + " Kayıt No'lu Sponsorlu Aracın Satışı Gerçekleştirildi.";

            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Duzenle", "Arac", new { id = ortakAraclar.KeyModalId }) });
        }

        [HttpPost]
        public JsonResult AracIptal(int aracId)
        {
            string mesaj = "";

            //Aracı pasife çekiyoruz
            var arac = _araclarService.GetById(aracId);
            arac.Aktif = false;
            arac.ModDate=DateTime.Now;
            arac.ModUser = HttpContext.User.Identity.Name;
            _araclarService.Update(arac);
            mesaj += "Araç, ";

            var aracGiderleri = _aracGiderlerService.GetByAracID(aracId);
            //Aracın oluşturduğu gelir kayıtları
            var aracGelir = _gelirKalemlerService.GetByKeyIdAndOlusturanIdList(arac.Id, 1);
            if (aracGelir.Count > 0)
            {
                foreach (var item in aracGelir)
                {
                    //Aracın oluşturduğu tüm gelir kayıtlarını pasife çekiyoruz
                    item.Aktif = false;
                    _gelirKalemlerService.Update(item);
                }
                mesaj += "Aracı Ürettiği Gelir, ";
            }
            //Aracın oluşturduğu gider kayıtları
            var aracGider = _giderKalemlerService.GetByKeyIdAndOlusturanIdList(arac.Id, 1);
            if (aracGider.Count > 0)
            {
                foreach (var item in aracGider)
                {
                    //Aracın oluşturduğu tüm gider kayıtlarını pasife çekiyoruz
                    item.Aktif = false;
                    _giderKalemlerService.Update(item);
                }
                mesaj += "Aracın Üretttiği Gider, ";
            }

            if (aracGiderleri.Count > 0)
            {
                foreach (var item in aracGiderleri)
                {
                    var gelenAracGiderler = _giderKalemlerService.GetByKeyIdAndOlusturanIdList(item.Id, 2);
                    foreach (var item2 in gelenAracGiderler)
                    {
                        //Aracın Giderlerinin oluşturduğu tüm araç gider kayıtlarını pasife çekiyoruz
                        item2.Aktif = false;
                        _giderKalemlerService.Update(item2);
                    }
                    //Arac Giderlerini Pasife Çekiyor
                    item.Aktif = false;
                    item.ModDate = DateTime.Now;
                    item.ModUser = HttpContext.User.Identity.Name;
                    _aracGiderlerService.Update(item);
                }
                mesaj += "Araç Giderleri ve Ürettiği Gider ";
            }

            if (mesaj != "")
            {
                mesaj += "Kayıtları Pasif Edildi.";
            }
            return Json(new { Success = true, Message = mesaj, url = Url.Action("Liste", "Arac") });
        }
        
        public AracRaporViewModel AracRapor(int aracId)
        {
            var aracRapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Arac_Rapor]")
                .WithSqlParams(
                    ("AracId", aracId))
                .ExecuteStoredProcedure<AracRaporViewModel>().FirstOrDefault();
            return aracRapor;

        }

        #region ComboBox
        public JsonResult CariGetir()
        {
            //Sponsor id'si 7 olduğu için
            var list = _carilerService.GetbyCariTip(7);
            return Json(new SelectList(list, "Id", "CariAd"));
        }

        public JsonResult ListDurum()
        {
            var list = _staticDetaylarService.GetByTanimId(1);
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }

        public JsonResult ListMarka()
        {
            List<ZAracMarkalar> list = new List<ZAracMarkalar>();
            list = _zAracMarkalarService.GetAll();
            list.Insert(0, new ZAracMarkalar() { Id = 0, MarkaAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "MarkaAd"));
        }

        public JsonResult ListModelByMarkaID(int markaID)
        {
            List<ZAracModeller> list = new List<ZAracModeller>();
            list = _zAracModellerService.GetByMarkaID(markaID);
            list.Insert(0, new ZAracModeller() { Id = 0, ModelAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "ModelAd"));
        }

        public JsonResult ListVersiyonByModelID(int modelID)
        {
            List<ZAracVersiyon> list = new List<ZAracVersiyon>();
            list = _zAracVersiyonlarService.GetByModelID(modelID);
            list.Insert(0, new ZAracVersiyon() { Id = 0, VersiyonAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "VersiyonAd"));
        }
        #endregion

    }
}