﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.HelperModels;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class AracGiderController : BaseController
    {
        private string ZorunluAlanlar = "IslemId,Tutar";

        private readonly IAracGiderlerService _aracGiderlerService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly IGiderKalemlerService _giderKalemlerService;
        private readonly IAraclarService _araclarService;
        public AracGiderController(IAracGiderlerService aracGiderlerService, IStaticDetaylarService staticDetaylarService, IGiderKalemlerService giderKalemlerService, IAraclarService araclarService)
        {
            _aracGiderlerService = aracGiderlerService;
            _staticDetaylarService = staticDetaylarService;
            _giderKalemlerService = giderKalemlerService;
            _araclarService = araclarService;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Ekle(int id)
        {
            var aracBilgi = _araclarService.GetById(id);
            var aracModel = new AracGiderler()
            {
                AracId = id
            };
            var model = new AracGiderViewModel()
            {
                AracGider = aracModel,
                Arac = aracBilgi
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName + "/" + id;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]AracGiderViewModel model)
        {

            model.AracGider.CreUser = HttpContext.User.Identity.Name;
            model.AracGider.ModUser = HttpContext.User.Identity.Name;
            model.AracGider.CreDate = DateTime.Now;
            model.AracGider.ModDate = DateTime.Now;
            _aracGiderlerService.Add(model.AracGider);

            var arac = _araclarService.GetById(model.AracGider.AracId);

            var giderModel = new GiderKalemler()
            {
                KeyId = model.AracGider.Id,
                OlusturanId = 2,
                CariId = 1,
                OrtakId = model.OrtakId1,
                Oran = model.OrtakOran1 ?? 0,
                Tutar = (model.AracGider.Tutar ?? 0) * Oran(model.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel2 = new GiderKalemler()
            {
                KeyId = model.AracGider.Id,
                OlusturanId = 2,
                CariId = 1,
                OrtakId = model.OrtakId2,
                Oran = model.OrtakOran2 ?? 0,
                Tutar = (model.AracGider.Tutar ?? 0) * Oran(model.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            if (arac.CariId != 1)
            {
                var giderModel3 = new GiderKalemler()
                {
                    KeyId = model.AracGider.Id,
                    OlusturanId = 2,
                    CariId = arac.CariId,
                    OrtakId = model.OrtakId3,
                    Oran = model.OrtakOran3 ?? 0,
                    Tutar = (model.AracGider.Tutar ?? 0) * Oran(model.OrtakOran3),
                    CreUser = HttpContext.User.Identity.Name,
                    CreDate = DateTime.Now
                };
                _giderKalemlerService.Add(giderModel3);
            }

            _giderKalemlerService.Add(giderModel);
            _giderKalemlerService.Add(giderModel2);
            TempData["message"] = model.AracGider.Id.ToString() + " Kayıt No'lu Araç Gider Kaydı Oluşturuldu.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Duzenle", "Arac", new { id = model.AracGider.AracId }) });
        }

        [HttpPost]
        public JsonResult AracGiderIptal(int aracGiderId)
        {
            var mesaj = "";
            var aracGider = _aracGiderlerService.GetById(aracGiderId);

            if (aracGider != null)
            {
                var gelenGiderKayitlari = _giderKalemlerService.GetByKeyIdAndOlusturanIdList(aracGider.Id, 2);
                foreach (var item in gelenGiderKayitlari)
                {
                    item.Aktif = false;
                    _giderKalemlerService.Update(item);
                }
                aracGider.Aktif = false;
                aracGider.ModDate = DateTime.Now;
                aracGider.ModUser = HttpContext.User.Identity.Name;
                _aracGiderlerService.Update(aracGider);
                mesaj += "Araç Gideri ve Oluşturduğu Gider Kayıtları Pasif Edildi.";
            }
           
            return Json(new { Success = true, Message = mesaj, url = Url.Action("Duzenle", "Arac", new { id = aracGider.AracId }) });
        }


        #region Combobox
            public JsonResult ListIslemTip(int tanimId)
        {
            List<StaticDetaylar> list = new List<StaticDetaylar>();
            list = _staticDetaylarService.GetByTanimId(tanimId);
            list.Insert(0, new StaticDetaylar() { Id = 0, StaticDetayAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }
        #endregion
    }
}