﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class AracMarkaController : BaseController
    {
        private string ZorunluAlanlar = "MarkaAd";

        private readonly IZAracMarkalarService _zAracMarkalarService;

        public AracMarkaController(IZAracMarkalarService zAracMarkalarService)
        {
            _zAracMarkalarService = zAracMarkalarService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste()
        {
            var tumListe = _zAracMarkalarService.GetAll();
            return View(tumListe);
        }

        public IActionResult Ekle()
        {
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(new ZAracMarkalar());
        }
        [HttpPost]
        public IActionResult Ekle([FromBody]ZAracMarkalar aracMarka)
        {
            if (_zAracMarkalarService.IsThere(aracMarka.MarkaAd, aracMarka.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracMarkalarService.Add(aracMarka);
                TempData["message"] = aracMarka.MarkaAd + " İsimli Marka Kaydedildi.";
                return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "AracMarka") });
            }
        }

        public IActionResult Duzenle(int id)
        {
            var duzenlenecekMarka = _zAracMarkalarService.GetById(id);
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(duzenlenecekMarka);
        }

        [HttpPost]
        public IActionResult Duzenle([FromBody]ZAracMarkalar aracMarka)
        {
            if (_zAracMarkalarService.IsThere(aracMarka.MarkaAd, aracMarka.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracMarkalarService.Update(aracMarka);
                TempData["message"] = aracMarka.MarkaAd + " İsimli Marka Düzenlendi.";
                return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "AracMarka") });
            }
        }
    }
}