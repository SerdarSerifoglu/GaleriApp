﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class AracModelController : BaseController
    {
        private string ZorunluAlanlar = "Id,MarkaId,ModelAd";

        private readonly IZAracModellerService _zAracModellerService;
        public AracModelController(IZAracModellerService zAracModellerService)
        {
            _zAracModellerService = zAracModellerService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste(int id, string markaad)
        {
            var list = _zAracModellerService.GetByMarkaID(id);
            var model = new AracModelViewModel()
            {
                Modeller = list,
                MarkaId = id,
                MarkaAd = markaad
            };
            return View(model);
        }

        public IActionResult Ekle(int markaId, string markaAd)
        {
            var aracModel = new ZAracModeller()
            {
                MarkaId = markaId
            };
            var model = new AracModelViewModel()
            {
                AracModel = aracModel,
                MarkaAd = markaAd
            };
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]AracModelViewModel model)
        {
            //Bu Markanın kayıtlı bu isimde modeli var mı?
            if (_zAracModellerService.IsThere(model.AracModel.ModelAd, model.AracModel.MarkaId ?? 0, model.AracModel.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracModellerService.Add(model.AracModel);
                TempData["message"] = model.AracModel.ModelAd + " İsimli Model Kaydedildi.";
                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "AracModel", new { id = model.AracModel.MarkaId, markaad = model.MarkaAd })
                });
            }

            //return View(model);
        }

        public IActionResult Duzenle(int id, string markaAd)
        {
            var gelenModel = _zAracModellerService.GetById(id);
            var model = new AracModelViewModel()
            {
                AracModel = gelenModel,
                MarkaAd = markaAd

            };
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Duzenle([FromBody]AracModelViewModel model)
        {
            if (_zAracModellerService.IsThere(model.AracModel.ModelAd, model.AracModel.MarkaId ?? 0, model.AracModel.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracModellerService.Update(model.AracModel);
                TempData["message"] = model.AracModel.ModelAd + " İsimli Model Düzenlendi.";
                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "AracModel", new { id = model.AracModel.MarkaId, markaad = model.MarkaAd })
                });
            }
        }
    }
}