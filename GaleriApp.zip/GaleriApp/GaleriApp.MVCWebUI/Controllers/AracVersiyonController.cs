﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class AracVersiyonController : BaseController
    {
        private string ZorunluAlanlar = "Id,ModelId,VersiyonAd";

        private readonly IZAracVersiyonlarService _zAracVersiyonlarService;
        public AracVersiyonController(IZAracVersiyonlarService zAracVersiyonlarService)
        {
            _zAracVersiyonlarService = zAracVersiyonlarService;
        }

        public IActionResult Liste(int id, string markaad, string modelad)
        {
            var list = _zAracVersiyonlarService.GetByModelID(id);
            var model = new AracVersiyonViewModel()
            {
                Versiyonlar = list,
                MarkaAd = markaad,
                ModelAd = modelad,
                ModelId = id
            };
            return View(model);
        }

        public IActionResult Ekle(int modelId, string markaad, string modelad)
        {
            var gelenModel = new ZAracVersiyon()
            {
                ModelId = modelId
            };
            var model = new AracVersiyonViewModel()
            {
                AracVersiyon = gelenModel,
                MarkaAd = markaad,
                ModelAd = modelad,
                ModelId = modelId
            };
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]AracVersiyonViewModel model)
        {
            if (_zAracVersiyonlarService.IsThere(model.AracVersiyon.VersiyonAd, model.AracVersiyon.ModelId ?? 0, model.AracVersiyon.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracVersiyonlarService.Add(model.AracVersiyon);
                TempData["message"] = model.AracVersiyon.VersiyonAd + " İsimli Versiyon Kaydedildi.";
                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "AracVersiyon", new { id = model.AracVersiyon.ModelId, markaad = model.MarkaAd, modelad = model.ModelAd })
                });
            }
        }

        public IActionResult Duzenle(int id, string markaad, string modelad)
        {
            var gelenModel = _zAracVersiyonlarService.GetById(id);
            var model = new AracVersiyonViewModel()
            {
                AracVersiyon = gelenModel,
                MarkaAd = markaad,
                ModelAd = modelad
            };
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Duzenle([FromBody]AracVersiyonViewModel model)
        {
            if (_zAracVersiyonlarService.IsThere(model.AracVersiyon.VersiyonAd, model.AracVersiyon.ModelId ?? 0, model.AracVersiyon.Id).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                _zAracVersiyonlarService.Update(model.AracVersiyon);
                TempData["message"] = model.AracVersiyon.VersiyonAd + " İsimli Versiyon Düzenlendi.";
                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "AracVersiyon", new { id = model.AracVersiyon.ModelId, markaad = model.MarkaAd, modelad = model.ModelAd })
                });
            }
        }
    }
}