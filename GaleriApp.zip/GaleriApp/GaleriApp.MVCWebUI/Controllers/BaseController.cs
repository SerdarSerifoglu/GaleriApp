﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class BaseController : Controller
    {
        //Json cevaplarında Kullanılıyorlar
        public static string KaydetOnayMesaj = "Kaydetme Başarılı";
        public static string AyniKayitMesaj = "Aynı İsimli Kayıt Zaten Var !";

        //Gelir Gider Kalem Kayıtları oluşturulurken Oran Hesabını yapıyor.
        public decimal Oran(decimal? val)
        {
            var returnValue = (val ?? 0) / 100;
            return returnValue;
        }
    }
}