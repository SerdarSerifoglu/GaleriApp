﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.VisualStudio.Web.CodeGeneration;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class BorcController : BaseController
    {
        private string ZorunluAlanlar = "DurumId,CariId,Tutar,OdenecekTutar,OrtakOran1,OrtakOran2";

        private readonly IBorclarService _borclarService;
        private readonly IBorcOdemelerService _borcOdemelerService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly ICarilerService _carilerService;
        private readonly IGelirKalemlerService _gelirKalemlerService;
        private readonly IGiderKalemlerService _giderKalemlerService;
        private readonly ISprocRepository _sprocRepository;
        public BorcController(IBorclarService borclarService, IBorcOdemelerService borcOdemelerService, IStaticDetaylarService staticDetaylarService, ICarilerService carilerService, IGelirKalemlerService gelirKalemlerService, IGiderKalemlerService giderKalemlerService, ISprocRepository sprocRepository)
        {
            _borclarService = borclarService;
            _borcOdemelerService = borcOdemelerService;
            _staticDetaylarService = staticDetaylarService;
            _carilerService = carilerService;
            _gelirKalemlerService = gelirKalemlerService;
            _giderKalemlerService = giderKalemlerService;
            _sprocRepository = sprocRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste()
        {
            var borclar = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Borclar_TamListe]")
                .ExecuteStoredProcedure<BorclarViewDTO>();
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(borclar);
        }

        public IActionResult Ekle()
        {
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName ;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(new BorclarViewModel()
            {
                Borc = new BorclarViewDTO() { DurumId = 4 }
            });
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]BorclarViewModel model)
        {
            model.Borc.CreUser = HttpContext.User.Identity.Name;
            model.Borc.ModUser = HttpContext.User.Identity.Name;
            model.Borc.CreDate = DateTime.Now;
            model.Borc.ModDate = DateTime.Now;
            model.Borc.KalanTutar = model.Borc.OdenecekTutar;
            //Borç sayfasında oluştuğu için
            model.Borc.OlusturanId = 5;
            _borclarService.Add(model.Borc);

            var sonBorc = _borclarService.GetByLastBorc();
            var gelirModel = new GelirKalemler()
            {
                KeyId = sonBorc.Id,
                OlusturanId = 5,
                CariId = 1,
                OrtakId = model.OrtakId1,
                Oran = model.OrtakOran1 ?? 0,
                Tutar = (model.Borc.Tutar ?? 0) * Oran(model.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirModel2 = new GelirKalemler()
            {
                KeyId = sonBorc.Id,
                OlusturanId = 5,
                CariId = 1,
                OrtakId = model.OrtakId2,
                Oran = model.OrtakOran2 ?? 0,
                Tutar = (model.Borc.Tutar ?? 0) * Oran(model.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _gelirKalemlerService.Add(gelirModel);
            _gelirKalemlerService.Add(gelirModel2);
            TempData["message"] = sonBorc.Id + " No'lu Borç Kaydı Oluşturuldu.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "Borc") });
        }

        public IActionResult Goruntule(int borcId)
        {
            var borc = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Borclar_TamListe]")
                .WithSqlParams(
                    ("BorcId", borcId))
                .ExecuteStoredProcedure<BorclarViewDTO>().FirstOrDefault();
            var borcOdemeler = _borcOdemelerService.GetByBorcIdList(borcId);
            var viewModel = new BorclarViewModel()
            {
                Borc = borc,
                BorcOdemeleri = borcOdemeler
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName + "?borcId=" + borcId;
            return View(viewModel);
        }

        public JsonResult BorcIptal(int borcId)
        {
            string mesaj = "";
            var borc = _borclarService.GetById(borcId);
            if (borc != null)
            {
                //Borç pasife çekildi
                borc.Aktif = false;
                borc.ModDate = DateTime.Now;
                borc.ModUser = HttpContext.User.Identity.Name;
                _borclarService.Update(borc);
                mesaj += "Borç, ";

                var borcGelirKayit = _gelirKalemlerService.GetByKeyIdAndOlusturanIdList(borc.Id, 5);
                foreach (var item in borcGelirKayit)
                {
                    //Borcun oluşturduğu gelir kayıtları pasife çekiliyor.
                    item.Aktif = false;
                    _gelirKalemlerService.Update(item);
                }

                mesaj += "Borcun Oluşturduğu Gelir , ";
                var borcOdemeler = _borcOdemelerService.GetByBorcIdList(borcId);
                if (borcOdemeler.Count > 0)
                {
                    foreach (var item in borcOdemeler)
                    {
                        var borcOdemeGiderKayitlari = _giderKalemlerService.GetByKeyIdAndOlusturanIdList(item.Id, 6);
                        if (borcOdemeGiderKayitlari.Count > 0)
                        {
                            foreach (var item2 in borcOdemeGiderKayitlari)
                            {
                                //Borç ödemelerin oluşturduğu gider kayıtları pasife çekiliyor.
                                item2.Aktif = false;
                                _giderKalemlerService.Update(item2);
                            }
                        }
                        //Borç ödemeler pasife çekildi
                        item.Aktif = false;
                        _borcOdemelerService.Update(item);
                    }
                    mesaj += "Borcun Ödemeleri ve Ödemelerin Oluşturduğu Gider ";
                }
            }

            if (mesaj !=null)
            {
                mesaj += "Kayıtları Pasif Edildi.";
            }

            return Json(new { Success = true, Message = mesaj, url = Url.Action("Liste", "Borc") });
        }


        #region ComboBox

        public JsonResult ListBorcDurum(int tanimId)
        {
            List<StaticDetaylar> list = new List<StaticDetaylar>();
            list = _staticDetaylarService.GetByTanimId(tanimId);
            list.Insert(0, new StaticDetaylar() { Id = 0, StaticDetayAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }

        public JsonResult CariGetir()
        {
            var list = _carilerService.GetNotIncludeId(1);
            list.Insert(0, new Cariler() { Id = 0, CariAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "CariAd"));
        }

        #endregion
    }
}