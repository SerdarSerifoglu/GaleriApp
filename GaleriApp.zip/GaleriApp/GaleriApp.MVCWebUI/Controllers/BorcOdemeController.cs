﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class BorcOdemeController : BaseController
    {
        private string ZorunluAlanlar = "BorcId,OdenenTutar,OrtakOran1,OrtakOran2";

        private readonly IBorcOdemelerService _borcOdemelerService;
        private readonly IBorclarService _borclarService;
        private readonly IGiderKalemlerService _giderKalemlerService;
        private readonly ISprocRepository _sprocRepository;
        public BorcOdemeController(IBorcOdemelerService borcOdemelerService, IBorclarService borclarService, IGiderKalemlerService giderKalemlerService, ISprocRepository sprocRepository)
        {
            _borcOdemelerService = borcOdemelerService;
            _borclarService = borclarService;
            _giderKalemlerService = giderKalemlerService;
            _sprocRepository = sprocRepository;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Ekle(int id)
        {
            var borc = _borclarService.GetById(id);
            var viewModel = new BorcOdemeViewModel()
            {
                Borc = borc,
                BorcOdeme = new BorcOdemeler()
                {
                    BorcId = borc.Id
                }
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName + "/" + id;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(viewModel);
        }
        [HttpPost]
        public IActionResult Ekle([FromBody]BorcOdemeViewModel model)
        {
            if (model.Borc.KalanTutar < model.BorcOdeme.OdenenTutar)
            {
                return Json(new {Success = false, Message = "Ödenen Tutar Kalan Borçtan Büyük Olamaz"});
            }
            model.BorcOdeme.CreUser = HttpContext.User.Identity.Name;
            model.BorcOdeme.CreDate = DateTime.Now;
            _borcOdemelerService.Add(model.BorcOdeme);

            var borc = _borclarService.GetById(model.BorcOdeme.BorcId ?? 0);
            borc.KalanTutar = borc.KalanTutar - model.BorcOdeme.OdenenTutar;
            if (borc.KalanTutar == 0)
            {
                borc.DurumId = 5;//Durum Ödendiye çevriliyor.
            }
            _borclarService.Update(borc);

            var sonBorcOdeme = _borcOdemelerService.GetByLastBorcOdemeInThisBorc(model.BorcOdeme.BorcId ?? 0);
            var giderModel = new GiderKalemler()
            {
                KeyId = sonBorcOdeme.Id,
                OlusturanId = 6,
                CariId = 1,
                OrtakId = model.OrtakId1,
                Oran = model.OrtakOran1 ?? 0,
                Tutar = (model.BorcOdeme.OdenenTutar ?? 0) * Oran(model.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel2 = new GiderKalemler()
            {
                KeyId = sonBorcOdeme.Id,
                OlusturanId = 6,
                CariId = 1,
                OrtakId = model.OrtakId2,
                Oran = model.OrtakOran2 ?? 0,
                Tutar = (model.BorcOdeme.OdenenTutar ?? 0) * Oran(model.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            _giderKalemlerService.Add(giderModel);
            _giderKalemlerService.Add(giderModel2);

            TempData["message"] = model.BorcOdeme.OdenenTutar + " ₺ Tutarında Borç Ödendi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Goruntule", "Borc", new { borcId = model.BorcOdeme.BorcId }) });
        }
    }
}