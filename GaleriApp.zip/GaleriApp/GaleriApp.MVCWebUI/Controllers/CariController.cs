﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class CariController : BaseController
    {
        private string ZorunluAlanlar = "CariAd,CariTipId";

        private readonly ICarilerService _carilerService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly IOrtaklarService _ortaklarService;
        private readonly ISprocRepository _sprocRepository;
        public CariController(ICarilerService carilerService, IStaticDetaylarService staticDetaylarService, IOrtaklarService ortaklarService, ISprocRepository sprocRepository)
        {
            _carilerService = carilerService;
            _staticDetaylarService = staticDetaylarService;
            _ortaklarService = ortaklarService;
            _sprocRepository = sprocRepository;
        }
        public IActionResult Index()
        {
            return RedirectToAction("Liste");
        }

        public IActionResult Liste()
        {
            var cariListe = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Cariler_TamListe]")
                .ExecuteStoredProcedure<CarilerViewDTO>();
            var model = new CarilerViewModel()
            {
                CariListe = cariListe
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(model);
        }

        public IActionResult Ekle()
        {
            var model = new CarilerViewModel()
            {
                Cari = new Cariler()
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]CarilerViewModel model)
        {
            model.Cari.CreUser = HttpContext.User.Identity.Name;
            model.Cari.CreDate = DateTime.Now;
            model.Cari.ModUser = HttpContext.User.Identity.Name;
            model.Cari.ModDate = DateTime.Now;
            _carilerService.Add(model.Cari);
            var sonCari = _carilerService.GetAll().OrderByDescending(x=>x.Id).FirstOrDefault();
            OrtakEkle(sonCari);
            TempData["message"] = model.Cari.CariAd + " İsimli Cari Kaydedildi.";
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "Cari") });
        }

        public IActionResult Duzenle(int id)
        {
            var gelenData = _carilerService.GetById(id);
            var model = new CarilerViewModel()
            {
                Cari = gelenData
            };
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName + "/" + id;
            return View(model);
        }

        [HttpPost]
        public IActionResult Duzenle(CarilerViewModel model)
        {
            model.Cari.ModDate = DateTime.Now;
            model.Cari.ModUser = HttpContext.User.Identity.Name;
            _carilerService.Update(model.Cari);
            TempData["message"] = model.Cari.CariAd + " İsimli Cari Düzenlendi.";
            return RedirectToAction("Liste");
        }

        public void OrtakEkle(Cariler model)
        {
            var ortakModel = new Ortaklar()
            {
                CariId = model.Id,
                OrtakAd = model.CariAd,
                OrtakOran = 100
            };
            _ortaklarService.Add(ortakModel);
        }

        #region ComboBox

        public JsonResult ListCariTip(int tanimId)
        {
            List<StaticDetaylar> list = new List<StaticDetaylar>();
            list = _staticDetaylarService.GetByTanimId(tanimId);
            list.Insert(0, new StaticDetaylar() { Id = 0, StaticDetayAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }

        #endregion
    }
}