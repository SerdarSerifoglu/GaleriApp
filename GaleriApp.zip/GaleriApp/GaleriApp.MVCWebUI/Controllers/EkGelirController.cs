﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class EkGelirController : BaseController
    {
        private string ZorunluAlanlar = "TipId,Tutar,OrtakOran1,OrtakOran2";

        private readonly IEkGelirlerService _ekGelirlerService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly IOrtaklarService _ortaklarService;
        private readonly IGelirKalemlerService _gelirKalemlerService;
        private readonly ISprocRepository _sprocRepository;

        public EkGelirController(IEkGelirlerService ekGelirlerService, IStaticDetaylarService staticDetaylarService, IOrtaklarService ortaklarService, IGelirKalemlerService gelirKalemlerService, ISprocRepository sprocRepository)
        {
            _ekGelirlerService = ekGelirlerService;
            _staticDetaylarService = staticDetaylarService;
            _ortaklarService = ortaklarService;
            _gelirKalemlerService = gelirKalemlerService;
            _sprocRepository = sprocRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste()
        {
            var ekGelirler = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_EkGelirler_TamListe]")
                .ExecuteStoredProcedure<EkGelirlerViewDTO>();
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(ekGelirler);
        }

        public IActionResult Ekle()
        {
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(new EkGelirViewModel());
        }
        [HttpPost]
        public IActionResult Ekle([FromBody]EkGelirViewModel model)
        {
            model.EkGelir.CariId = 1;
            model.EkGelir.CreUser = HttpContext.User.Identity.Name;
            model.EkGelir.ModUser = HttpContext.User.Identity.Name;
            model.EkGelir.CreDate = DateTime.Now;
            model.EkGelir.ModDate = DateTime.Now;
            _ekGelirlerService.Add(model.EkGelir);

            var sonEkGelir = _ekGelirlerService.GetByLastEkGelir();
            var gelirModel = new GelirKalemler()
            {
                KeyId = sonEkGelir.Id,
                OlusturanId = 3,
                CariId = sonEkGelir.CariId,
                OrtakId = model.OrtakId1,
                Oran = model.OrtakOran1 ?? 0,
                Tutar = (model.EkGelir.Tutar ?? 0) * Oran(model.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var gelirModel2 = new GelirKalemler()
            {
                KeyId = sonEkGelir.Id,
                OlusturanId = 3,
                CariId = sonEkGelir.CariId,
                OrtakId = model.OrtakId2,
                Oran = model.OrtakOran2 ?? 0,
                Tutar = (model.EkGelir.Tutar ?? 0) * Oran(model.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _gelirKalemlerService.Add(gelirModel);
            _gelirKalemlerService.Add(gelirModel2);

            TempData["message"] = model.EkGelir.Id + " Kayıt No'lu Ek Gelir kaydedildi. Tutar: " + model.EkGelir.Tutar;
            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "EkGelir")});
        }

        [HttpPost]
        public JsonResult EkGelirIptal(int ekGelirId)
        {
            var mesaj = "";
            var ekGelir = _ekGelirlerService.GetById(ekGelirId);

            if (ekGelir != null)
            {
                var gelenGiderKayitlari = _gelirKalemlerService.GetByKeyIdAndOlusturanIdList(ekGelir.Id, 3);
                foreach (var item in gelenGiderKayitlari)
                {
                    item.Aktif = false;
                    _gelirKalemlerService.Update(item);
                }
                ekGelir.Aktif = false;
                ekGelir.ModDate = DateTime.Now;
                ekGelir.ModUser = HttpContext.User.Identity.Name;
                _ekGelirlerService.Update(ekGelir);
                mesaj += "Ek Gelir ve Oluşturduğu Gelir Kayıtları Pasif Edildi.";
            }

            return Json(new { Success = true, Message = mesaj, url = Url.Action("Liste", "EkGelir") });
        }

        
        #region ComboBox

        public JsonResult ListGelirTip(int tanimId)
        {
            List<StaticDetaylar> list = new List<StaticDetaylar>();
            list = _staticDetaylarService.GetByTanimId(tanimId);
            list.Insert(0, new StaticDetaylar() { Id = 0, StaticDetayAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }

        #endregion
    }
}