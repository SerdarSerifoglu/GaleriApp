﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class EkGiderController : BaseController
    {
        private string ZorunluAlanlar = "TipId,Tutar,OrtakOran1,OrtakOran2";

        private readonly IEkGiderlerService _ekGiderlerService;
        private readonly IGiderKalemlerService _giderKalemlerService;
        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly ISprocRepository _sprocRepository;
        public EkGiderController(IEkGiderlerService ekGiderlerService, IGiderKalemlerService giderKalemlerService, IStaticDetaylarService staticDetaylarService, ISprocRepository sprocRepository)
        {
            _ekGiderlerService = ekGiderlerService;
            _giderKalemlerService = giderKalemlerService;
            _staticDetaylarService = staticDetaylarService;
            _sprocRepository = sprocRepository;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Liste()
        {
            var ekGiderler = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_EkGiderler_TamListe]")
                .ExecuteStoredProcedure<EkGiderlerViewDTO>();
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            return View(ekGiderler);
        }
        public IActionResult Ekle()
        {
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(new EkGiderViewModel());
        }
        [HttpPost]
        public IActionResult Ekle([FromBody]EkGiderViewModel model)
        {
            model.EkGider.CariId = 1;
            model.EkGider.CreUser = HttpContext.User.Identity.Name;
            model.EkGider.ModUser = HttpContext.User.Identity.Name;
            model.EkGider.CreDate = DateTime.Now;
            model.EkGider.ModDate = DateTime.Now;
            _ekGiderlerService.Add(model.EkGider);

            var sonEkGider = _ekGiderlerService.GetByLastEkGider();
            var giderModel = new GiderKalemler()
            {
                KeyId = sonEkGider.Id,
                OlusturanId = 4,
                CariId = sonEkGider.CariId,
                OrtakId = model.OrtakId1,
                Oran = model.OrtakOran1 ?? 0,
                Tutar = (model.EkGider.Tutar ?? 0) * Oran(model.OrtakOran1),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };
            var giderModel2 = new GiderKalemler()
            {
                KeyId = sonEkGider.Id,
                OlusturanId = 4,
                CariId = sonEkGider.CariId,
                OrtakId = model.OrtakId2,
                Oran = model.OrtakOran2 ?? 0,
                Tutar = (model.EkGider.Tutar ?? 0) * Oran(model.OrtakOran2),
                CreUser = HttpContext.User.Identity.Name,
                CreDate = DateTime.Now
            };

            _giderKalemlerService.Add(giderModel);
            _giderKalemlerService.Add(giderModel2);

            TempData["message"] = model.EkGider.Id + " Kayıt No'lu Ek Gider kaydedildi. Tutar: " + model.EkGider.Tutar;

            return Json(new { Success = true, Message = KaydetOnayMesaj, url = Url.Action("Liste", "EkGider") });
        }

        [HttpPost]
        public JsonResult EkGiderIptal(int ekGiderId)
        {
            var mesaj = "";
            var ekGider = _ekGiderlerService.GetById(ekGiderId);

            if (ekGider != null)
            {
                var gelenGiderKayitlari = _giderKalemlerService.GetByKeyIdAndOlusturanIdList(ekGider.Id, 4);
                foreach (var item in gelenGiderKayitlari)
                {
                    item.Aktif = false;
                    _giderKalemlerService.Update(item);
                }
                ekGider.Aktif = false;
                ekGider.ModDate = DateTime.Now;
                ekGider.ModUser = HttpContext.User.Identity.Name;
                _ekGiderlerService.Update(ekGider);
                mesaj += "Ek Gider ve Oluşturduğu Gider Kayıtları Pasif Edildi.";
            }

            return Json(new { Success = true, Message = mesaj, url = Url.Action("Liste", "EkGider") });
        }


        #region ComboBox

        public JsonResult ListGiderTip(int tanimId)
        {
            List<StaticDetaylar> list = new List<StaticDetaylar>();
            list = _staticDetaylarService.GetByTanimId(tanimId);
            list.Insert(0, new StaticDetaylar() { Id = 0, StaticDetayAd = "Seçiniz" });
            return Json(new SelectList(list, "Id", "StaticDetayAd"));
        }

        #endregion
    }
}