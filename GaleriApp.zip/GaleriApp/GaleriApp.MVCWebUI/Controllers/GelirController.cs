﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class GelirController : BaseController
    {
        private readonly ISprocRepository _sprocRepository;

        public GelirController(ISprocRepository sprocRepository)
        {
            _sprocRepository = sprocRepository;
        }
        public IActionResult Index()
        {
            return RedirectToAction("Liste");
        }
        public IActionResult Liste(GelirKalemlerFilter filter)
        {
            var gelirler = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_GelirKalemler_TamListe]")
                .WithSqlParams(
                    ("KeyID", filter.KeyID),
                    ("OlusturanID", filter.OlusturanID),
                    ("OrtakID", filter.OrtakID))
                .ExecuteStoredProcedure<GelirKalemlerViewDTO>();
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            var model = new GelirKalemViewModel()
            {
                GelirKalemler = gelirler
            };
            return View(model);
        }
    }
}