﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class GiderController : BaseController
    {
        private readonly ISprocRepository _sprocRepository;
        public GiderController(ISprocRepository sprocRepository)
        {
            _sprocRepository = sprocRepository;
        }
        public IActionResult Index()
        {
            return RedirectToAction("Liste");
        }

        public IActionResult Liste(GiderKalemlerFilter filter)
        {
            var giderler = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_GiderKalemler_TamListe]")
                .WithSqlParams(
                    ("KeyID", filter.KeyID),
                    ("OlusturanID", filter.OlusturanID),
                    ("OrtakID", filter.OrtakID))
                .ExecuteStoredProcedure<GiderKalemlerViewDTO>();
            string actionName = this.ControllerContext.RouteData.Values["action"].ToString();
            string controllerName = this.ControllerContext.RouteData.Values["controller"].ToString();
            ViewBag.StartURL = "/" + controllerName + "/" + actionName;
            var model = new GiderKalemViewModel()
            {
                GiderKalemler = giderler
            };
            return View(model);
        }
    }
}