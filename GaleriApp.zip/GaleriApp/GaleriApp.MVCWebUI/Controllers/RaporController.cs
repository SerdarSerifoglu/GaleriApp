﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.Entity.Filters;
using GaleriApp.Entity.Models;
using GaleriApp.Entity.ViewModels;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class RaporController : Controller
    {
        private readonly ISprocRepository _sprocRepository;
        private readonly IOrtaklarService _ortaklarService;
        public RaporController(ISprocRepository sprocRepository, IOrtaklarService ortaklarService)
        {
            _sprocRepository = sprocRepository;
            _ortaklarService = ortaklarService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard(int cariId)
        {
            var rapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_Dashboard]")
                .ExecuteStoredProcedure<RaporViewModel>().FirstOrDefault();
            var raporBilanco = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_GelirGider]")
                .WithSqlParams(
                    ("CariId", cariId))
                .ExecuteStoredProcedure<RaporBilancoViewModel>().FirstOrDefault();
            var model = new RaporlarViewModel()
            {
                RaporViewModel = rapor,
                RaporBilancoViewModel = raporBilanco
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult Dashboard(RaporFilter filter)
        {
            var rapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_Dashboard]")
                .ExecuteStoredProcedure<RaporViewModel>().FirstOrDefault();
            var raporBilanco = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_GelirGider]")
                .WithSqlParams(
                    ("CariId", filter.CariID),
                    ("Tarih1", filter.Tarih1),
                    ("Tarih2", filter.Tarih2))
                .ExecuteStoredProcedure<RaporBilancoViewModel>().FirstOrDefault();
            var model = new RaporlarViewModel()
            {
                RaporViewModel = rapor,
                RaporBilancoViewModel = raporBilanco
            };
            return View(model);
        }

        public IActionResult Bilanco(int cariId)
        {
            var rapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_GelirGider]")
                .WithSqlParams(
                    ("CariId", cariId))
                .ExecuteStoredProcedure<RaporBilancoViewModel>().FirstOrDefault();
            return View(rapor);
        }
        
        public IActionResult SponsorRapor()
        {
            return View(new RaporSponsorViewModel());
        }

        [HttpPost]
        public IActionResult SponsorRapor(RaporFilter filter)
        {
            var rapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_Sponsor]")
                .WithSqlParams(
                    ("CariID", filter.CariID))
                .ExecuteStoredProcedure<RaporSponsorViewModel>().FirstOrDefault();
            return View(rapor);
        }

        public IActionResult OrtakRapor()
        {
            return View(new RaporOrtakViewModel());
        }

        [HttpPost]
        public IActionResult OrtakRapor(RaporFilter filter)
        {
            var rapor = _sprocRepository
                .GetStoredProcedure("[dbo].[sp_Rapor_Ortak]")
                .WithSqlParams(
                    ("OrtakID", filter.OrtakID))
                .ExecuteStoredProcedure<RaporOrtakViewModel>().FirstOrDefault();
            return View(rapor);
        }


        public JsonResult OrtakGetir(int cariId)
        {
            //Sponsor id'si 7 olduğu için
            var list = _ortaklarService.GetByCariID(1);
            return Json(new SelectList(list, "Id", "OrtakAd"));
        }
    }
}