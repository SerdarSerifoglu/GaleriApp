﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.Models;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class StaticDetayController : BaseController
    {
        private string ZorunluAlanlar = "TanimId,StaticDetayAd";

        private readonly IStaticDetaylarService _staticDetaylarService;
        private readonly IStaticTanimlarService _staticTanimlarService;
        public StaticDetayController(IStaticDetaylarService staticDetaylarService, IStaticTanimlarService staticTanimlarService)
        {
            _staticDetaylarService = staticDetaylarService;
            _staticTanimlarService = staticTanimlarService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste(int id)
        {
            var staticDetaylar = _staticDetaylarService.GetByTanimId(id);
            var staticTanim = _staticTanimlarService.GetById(id);
            var model = new StaticDetayViewModel()
            {
                StaticDetaylar = staticDetaylar,
                StaticTanim = staticTanim,
                StaticTanimId = id
            };

            return View(model);
        }

        public IActionResult Ekle(int tanimId)
        {
            var model = new StaticDetayViewModel()
            {
                StaticDetay = new StaticDetaylar() { TanimId = tanimId },
                StaticTanimId = tanimId
            };

            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }

        [HttpPost]
        public IActionResult Ekle([FromBody]StaticDetayViewModel model)
        {
            if (_staticDetaylarService.IsThere(model.StaticDetay.StaticDetayAd, model.StaticDetay.Id, model.StaticDetay.TanimId).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                model.StaticDetay.CreDate = DateTime.Now;
                model.StaticDetay.ModDate = DateTime.Now;
                model.StaticDetay.CreUser = HttpContext.User.Identity.Name;
                model.StaticDetay.ModUser = HttpContext.User.Identity.Name;
                _staticDetaylarService.Add(model.StaticDetay);
                TempData["message"] = model.StaticDetay.Id + " Kayıt No'lu Statik Detay Kaydedildi. İsim: " +
                                      model.StaticDetay.StaticDetayAd;

                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "StaticDetay", new { id = model.StaticDetay.TanimId })
                });
            }
        }

        public IActionResult Duzenle(int id)
        {
            var gelenModel = _staticDetaylarService.GetById(id);

            var model = new StaticDetayViewModel()
            {
                StaticDetay = gelenModel,
                StaticTanimId = id
            };
            ViewBag.ZorunluAlanlar = ZorunluAlanlar;
            return View(model);
        }
        [HttpPost]
        public IActionResult Duzenle([FromBody]StaticDetayViewModel model)
        {
            if (_staticDetaylarService.IsThere(model.StaticDetay.StaticDetayAd, model.StaticDetay.Id, model.StaticDetay.TanimId).Count > 0)
            {
                return Json(new { Success = false, Message = AyniKayitMesaj });
            }
            else
            {
                model.StaticDetay.ModDate = DateTime.Now;
                model.StaticDetay.ModUser = HttpContext.User.Identity.Name;
                _staticDetaylarService.Update(model.StaticDetay);
                TempData["message"] = model.StaticDetay.Id + " Kayıt No'lu Statik Detay Düzenlendi. İsim: " +
                                      model.StaticDetay.StaticDetayAd;
                return Json(new
                {
                    Success = true,
                    Message = KaydetOnayMesaj,
                    url = Url.Action("Liste", "StaticDetay", new { id = model.StaticDetay.TanimId })
                });
            }
        }

        //Yapılacak başka yerde kullanılmış mı kontrol yapılıp silinecek
        //public IActionResult Sil(int id)
        //{
        //    var gelenModel = _staticDetaylarService.GetById(id);

        //}
    }
}