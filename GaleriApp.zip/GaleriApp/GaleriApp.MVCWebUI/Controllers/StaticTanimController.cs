﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GaleriApp.MVCWebUI.Controllers
{
    [Authorize]
    public class StaticTanimController : BaseController
    {
        private readonly IStaticTanimlarService _staticTanimlarService;

        public StaticTanimController(IStaticTanimlarService staticTanimlarService)
        {
            _staticTanimlarService = staticTanimlarService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Liste()
        {
            var staticTanimlar = _staticTanimlarService.GetAll();
            return View(staticTanimlar);
        }

    }
}