﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GaleriApp.MVCWebUI.Models
{
    public class AracRaporViewModel
    {
        [Display(Name = "Aracın Satıldığı Tutar")]
        public decimal? SatisFiyati { get; set; }
        [Display(Name = "Aracın Alındığı Tutar")]
        public decimal? AlisFiyati { get; set; }
        [Display(Name = "Araca Yapılan GiderleriToplam Tutarı")]
        public decimal? AracGiderleriToplam { get; set; }
        [Display(Name = "Araçtan Elden Edilen Getiri Tutarı")]
        public decimal? AracinToplamGetirisi { get; set; }
    }
}
