﻿using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using GaleriApp.Entity.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;

namespace GaleriApp.MVCWebUI.Models
{
    public class AracVersiyonViewModel
    {
        public List<ZAracVersiyon> Versiyonlar { get; set; }
        public ZAracVersiyon AracVersiyon { get; set; }
        public string MarkaAd { get; set; }
        public string ModelAd { get; set; }
        public int? ModelId { get; set; }
    }
}