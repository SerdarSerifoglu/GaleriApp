﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class AraclarViewModel
    {
        public AraclarViewModel()
        {
            //AracGiderler = new IList<AracGiderlerViewDTO>();
        }
        public Araclar Arac { get; set; }
        public IList<AracGiderlerViewDTO> AracGiderler { get; set; }
        [Display(Name = "Araç Sahibi")]
        public string CariAd { get; set; }
        public AracRaporViewModel AracRapor { get; set; }
    }
}
