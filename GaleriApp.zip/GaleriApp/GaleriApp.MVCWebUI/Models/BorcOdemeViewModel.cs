﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class BorcOdemeViewModel
    {
        public Borclar Borc { get; set; }
        public BorcOdemeler BorcOdeme { get; set; }
        public int? OrtakId1 { get; set; }
        public decimal? OrtakOran1 { get; set; }
        public int? OrtakId2 { get; set; }
        public decimal? OrtakOran2 { get; set; }
    }
}
