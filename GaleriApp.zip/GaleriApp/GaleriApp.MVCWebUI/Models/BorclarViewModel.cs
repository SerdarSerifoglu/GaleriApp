﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class BorclarViewModel
    {
        public BorclarViewModel()
        {
            Borc = new BorclarViewDTO();
            BorcOdemeleri = new List<BorcOdemeler>();
        }
        public BorclarViewDTO Borc { get; set; }
        public List<BorcOdemeler> BorcOdemeleri { get; set; }
        public int? OrtakId1 { get; set; }
        public decimal? OrtakOran1 { get; set; }
        public int? OrtakId2 { get; set; }
        public decimal? OrtakOran2 { get; set; }
    }
}
