﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class GiderKalemViewModel
    {
        public IList<GiderKalemlerViewDTO> GiderKalemler { get; set; }
    }
}
