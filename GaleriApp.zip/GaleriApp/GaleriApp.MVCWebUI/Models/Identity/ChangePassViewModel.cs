﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GaleriApp.MVCWebUI.Models.Identity
{
    public class ChangePassViewModel
    {
        [Display(Name ="Şuanki Şifre")]
        [Required(ErrorMessage ="Şu anki şifrenizi girmelisiniz")]
        [DataType(DataType.Password)]
        public string CurrentPassword { get; set; }
        [Display(Name = "Yeni Şifre")]
        [Required(ErrorMessage = "Yeni şifrenizi girmelisiniz")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Display(Name = "Şifresi Değiştirilecek Kullanıcı")]
        [Required(ErrorMessage = "Kullanıcı Adı girmelisiniz")]
        public string Username { get; set; }
    }
}
