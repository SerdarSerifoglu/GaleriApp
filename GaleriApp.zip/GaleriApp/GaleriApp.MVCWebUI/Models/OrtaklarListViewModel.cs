﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class OrtaklarListViewModel
    {
        public List<Ortaklar> Ortaklar { get; internal set; }
        public int DurumId { get; set; }
    }
}
