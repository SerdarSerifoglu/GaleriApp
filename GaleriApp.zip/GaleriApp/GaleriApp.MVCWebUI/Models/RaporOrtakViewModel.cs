﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GaleriApp.MVCWebUI.Models
{
    public class RaporOrtakViewModel
    {
        public decimal? GelirlerToplami { get; set; }
        public decimal? GiderlerToplami { get; set; }
        public decimal? ToplamSermaye { get; set; }
        public decimal? SermayeDisiToplamGelir { get; set; }
        public decimal? NetKar { get; set; }
        public string OrtakAd { get; set; }
        public int? OrtakID { get; set; }
        public int? CariID { get; set; }
    }
}
