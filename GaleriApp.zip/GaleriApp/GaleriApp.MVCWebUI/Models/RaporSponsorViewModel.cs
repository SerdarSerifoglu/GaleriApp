﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GaleriApp.MVCWebUI.Models
{
    public class RaporSponsorViewModel
    {
        public decimal? SatistakiAraclarininTutari { get; set; }
        public decimal? YatirilanPara { get; set; }
        public decimal? KalanPara { get; set; }
        public decimal? GelirlerToplami { get; set; }
        public decimal? GiderlerToplami { get; set; }
        public string CariAd { get; set; }
        public int? CariId { get; set; }
        public decimal? NetKar { get; set; }
    }
}
