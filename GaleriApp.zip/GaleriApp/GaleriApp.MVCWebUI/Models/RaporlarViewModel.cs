﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.ViewModels;

namespace GaleriApp.MVCWebUI.Models
{
    public class RaporlarViewModel
    {
        public RaporViewModel RaporViewModel { get; set; }
        public RaporBilancoViewModel RaporBilancoViewModel { get; set; }
    }
}
