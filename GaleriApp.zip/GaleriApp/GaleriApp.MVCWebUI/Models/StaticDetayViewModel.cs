﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.Entity.Models;

namespace GaleriApp.MVCWebUI.Models
{
    public class StaticDetayViewModel
    {
        public List<StaticDetaylar> StaticDetaylar { get; set; }
        public StaticDetaylar StaticDetay { get; set; }
        public StaticTanimlar StaticTanim { get; set; }
        public int StaticTanimId { get; set; }
    }
}
