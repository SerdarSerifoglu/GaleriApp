﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.BLL.Concrete;
using GaleriApp.DAL.Abstract;
using GaleriApp.DAL.Concrete;
using GaleriApp.MVCWebUI.Entities;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Serialization;

namespace GaleriApp.MVCWebUI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            //DependencyInjection
            services.AddScoped<IAraclarService, AraclarManager>();
            services.AddScoped<IAraclarDal, EfAraclarDal>();
            services.AddScoped<IAracGiderlerService, AracGiderlerManager>();
            services.AddScoped<IAracGiderlerDal, EfAracGiderlerDal>();
            services.AddScoped<IEkGelirlerService, EkGelirlerManager>();
            services.AddScoped<IEkGelirlerDal, EfEkGelirlerDal>();
            services.AddScoped<IEkGiderlerService, EkGiderlerManager>();
            services.AddScoped<IEkGiderlerDal, EfEkGiderlerDal>();
            services.AddScoped<IBorclarService, BorclarManager>();
            services.AddScoped<IBorclarDal, EfBorclarDal>();
            services.AddScoped<IBorcOdemelerService, BorcOdemelerManager>();
            services.AddScoped<IBorcOdemelerDal, EfBorcOdemelerDal>();
            services.AddScoped<IZAracMarkalarService, ZAracMarkalarManager>();
            services.AddScoped<IZAracMarkalarDal, EfZAracMarkalarDal>();
            services.AddScoped<IZAracModellerService, ZAracModellerManager>();
            services.AddScoped<IZAracModellerDal, EfZAracModellerDal>();
            services.AddScoped<IZAracVersiyonlarService, ZAracVersiyonlarManager>();
            services.AddScoped<IZAracVersiyonlarDal, EfZAracVersiyonlarDal>();
            services.AddScoped<IOrtaklarService, OrtaklarManager>();
            services.AddScoped<IOrtaklarDal, EfOrtaklarDal>();
            services.AddScoped<IStaticTanimlarService, StaticTanimlarManager>();
            services.AddScoped<IStaticTanimlarDal, EfStaticTanimlarDal>();
            services.AddScoped<IStaticDetaylarService, StaticDetaylarManager>();
            services.AddScoped<IStaticDetaylarDal, EfStaticDetaylarDal>();
            services.AddScoped<IGelirKalemlerService, GelirKalemlerManager>();
            services.AddScoped<IGelirKalemlerDal, EfGelirKalemlerDal>();
            services.AddScoped<IGiderKalemlerService, GiderKalemlerManager>();
            services.AddScoped<IGiderKalemlerDal, EfGiderKalemlerDal>();
            services.AddScoped<ICarilerService, CarilerManager>();
            services.AddScoped<ICarilerDal, EfCarilerDal>();

            //@Html.Raw(Json.Serialize(ZorunluAlanlar)); sayfalarda bu şekilde dönüştürülen jsonların property isimlerinin camel case ile yazılmasını engelledi.
            services.AddMvc().AddJsonOptions(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });
            ////Cookielerin kaldırılma süresi (LogOff vs.)
            //services.ConfigureApplicationCookie(options =>
            //{
            //    options.ExpireTimeSpan = TimeSpan.FromSeconds(2);
            //});

            services.AddDbContext<CustomIdentityDbContext>(options =>
                options.UseSqlServer(Configuration["ConnectionStrings:DefaultConnectionString"]));
            
            services.AddIdentity<CustomIdentityUser, CustomIdentityRole>()
                .AddEntityFrameworkStores<CustomIdentityDbContext>()
                .AddDefaultTokenProviders();

            services.Configure<IdentityOptions>(options =>
            {
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequiredLength = 6;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireUppercase = false;
            });

            services.AddDbContext<SpIcinDbContext>(options =>
                options.UseSqlServer(Configuration["ConnectionStrings:DefaultConnectionString"]));
            services.AddScoped<ISprocRepository, SprocRepository>();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseIdentity();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
