﻿using GaleriApp.BLL.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace GaleriApp.MVCWebUI.ViewComponents
{
    public class KismiOrtakFormViewComponent : ViewComponent
    {
        private readonly IOrtaklarService _ortaklarService;

        public KismiOrtakFormViewComponent(IOrtaklarService ortaklarService)
        {
            _ortaklarService = ortaklarService;
        }

        public ViewViewComponentResult Invoke(int cariId)
        {
            var model = new OrtaklarListViewModel
            {
                Ortaklar = _ortaklarService.GetByCariIDor1(cariId)
            };
            return View(model);
        }
    }
}
