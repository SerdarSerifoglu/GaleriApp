﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace GaleriApp.MVCWebUI.ViewComponents
{
    public class KismiOrtakliViewComponent : ViewComponent
    {
        private string ZorunluAlanlar = "KeyModalId,OrtakOran1,OrtakOran2,OrtakOran3,AracAlisFiyati,AracAlinanKisi";
        private string ZorunluAlanlarAracSatis = "KeyModalId,OrtakOran1,OrtakOran2,OrtakOran3,AracSatisFiyati,AracSatilanKisi";

        private readonly IOrtaklarService _ortaklarService;

        public KismiOrtakliViewComponent(IOrtaklarService ortaklarService)
        {
            _ortaklarService = ortaklarService;
        }

        public ViewViewComponentResult Invoke(int durumId, int cariId)
        {
            var model = new OrtaklarListViewModel()
            {
                Ortaklar = _ortaklarService.GetByCariIDor1(cariId),
                DurumId = durumId
            };
            ViewBag.ZorunluAlanlarAracAlimiKismiOrtakli = ZorunluAlanlar;
            ViewBag.ZorunluAlanlarAracSatisKismiOrtakli = ZorunluAlanlarAracSatis;
            return View(model);
        }
    }
}
