﻿using GaleriApp.BLL.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace GaleriApp.MVCWebUI.ViewComponents
{
    public class OrtakFormViewComponent : ViewComponent
    {
        private readonly IOrtaklarService _ortaklarService;

        public OrtakFormViewComponent(IOrtaklarService ortaklarService)
        {
            _ortaklarService = ortaklarService;
        }

        public ViewViewComponentResult Invoke()
        {
            var model = new OrtaklarListViewModel
            {
                Ortaklar = _ortaklarService.GetByCariID(1)
            };
            return View(model);
        }
    }
}
