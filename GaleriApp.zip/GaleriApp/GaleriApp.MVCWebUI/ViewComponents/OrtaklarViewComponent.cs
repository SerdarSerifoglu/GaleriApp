﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GaleriApp.BLL.Abstract;
using GaleriApp.MVCWebUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace GaleriApp.MVCWebUI.ViewComponents
{
    public class OrtaklarViewComponent : ViewComponent
    {
        private string ZorunluAlanlar = "KeyModalId,OrtakOran1,OrtakOran2,AracAlisFiyati,AracAlinanKisi";
        private string ZorunluAlanlarAracSatis = "KeyModalId,OrtakOran1,OrtakOran2,AracSatisFiyati,AracSatilanKisi";

        private readonly IOrtaklarService _ortaklarService;

        public OrtaklarViewComponent(IOrtaklarService ortaklarService)
        {
            _ortaklarService = ortaklarService;
        }

        public ViewViewComponentResult Invoke(int durumId)
        {
            var model = new OrtaklarListViewModel()
            {
                Ortaklar = _ortaklarService.GetByCariID(1),
                DurumId = durumId
            };
            ViewBag.ZorunluAlanlarAracAlimi = ZorunluAlanlar;
            ViewBag.ZorunluAlanlarAracSatis = ZorunluAlanlarAracSatis;
            return View(model);
        }
    }
}
