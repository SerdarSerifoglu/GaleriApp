﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

//yollanan id'yi disabled yapıyor
function readOnlyInput(id) {
    $("#" + id).prop("disabled", true);
    //$("#" + id).css("color", "#c0c0c0");
}

//İnputlardan data toplama
getValues = function (m, preKey) {
    var DATE_START = "/Date(";
    var r = m;
    var keys = Object.keys(r);
    if (preKey === undefined) { preKey = ""; }
    preKey = "#" + preKey;

    for (j = 0; j < keys.length; j++) {
        if ($(preKey + keys[j]).length) //nesne varmı
        {
            // if ($(preKey + keys[j]).data("kendoComboBox")) {
            //     r[keys[j]] = $(preKey + keys[j]).data("kendoComboBox").value();
            // }

            // else if ($(preKey + keys[j]).data("kendoDatePicker")) {
            //     var val = $(preKey + keys[j]).data("kendoDatePicker").value();
            //     if (val)
            //         r[keys[j]] = val.toISOString();
            //     else
            //         r[keys[j]] = null;
            // }
            // else if ($(preKey + keys[j]).data("kendoDateTimePicker")) {
            //     var val = $(preKey + keys[j]).data("kendoDateTimePicker").value();
            //     if (val)
            //         r[keys[j]] = val.toISOString();
            //     else
            //         r[keys[j]] = null;
            // }
            // else if ($(preKey + keys[j]).data("kendoMaskedTextBox"))
            //     r[keys[j]] = $(preKey + keys[j]).data("kendoMaskedTextBox").value().replace('.', ',');

            // else if ($(preKey + keys[j]).attr('type') === "checkbox")
            //     r[keys[j]] = $(preKey + keys[j]).prop("checked");
            // else
            //     r[keys[j]] = $(preKey + keys[j]).val();
            if ($(preKey + keys[j]).attr('type') === "checkbox")
                r[keys[j]] = $(preKey + keys[j]).prop("checked");
            else
                r[keys[j]] = $(preKey + keys[j]).val();
        }

    }
    return r;
};



//Post İşlemleri
post = function (url, data, bsariCallback, hataCallbakc) {
    _ajaxJson(url, data, bsariCallback, hataCallbakc, "post");
};
_ajax = function (url, data, basariCallback, hataCallback, type) {
    $.ajaxSetup({
        cache: false
    });
    $.ajax({
        url: url,
        type: type,
        data: data,
        error: function (response) {

            if (hataCallback) {
                hataCallback(response);
            }

        },
        success: function (response) {

            if (basariCallback) {
                basariCallback(response);
            }
            else {
                if (!response.IsSuccess && response.HttpHataKodu && response.HttpHataKodu == 401) {
                    windows.location.href = LOGIN_URL;
                }
            }
        },
        complete: function () {
            //$(placeholder).removeClass('loading');
        },

    });
};

_ajaxJson = function (url, data, basariCallback, hataCallback, type) {
    $.ajaxSetup({
        cache: false
    });
    $.ajax({
        url: url,
        type: type,
        data: JSON.stringify(data),
        dataType: 'json',
        contentType: 'application/Json',
        traditional: true,
        error: function (response) {
            if (hataCallback) {
                hataCallback(response);
            }
            else {
                console.log(response);
            }
        },
        success: function (response) {
            if (basariCallback) {
                basariCallback(response);
            }
            else {
                if (!response.IsSuccess && response.HttpHataKodu && response.HttpHataKodu === 401) {
                    windows.location.href = LOGIN_URL;
                }
            }
        },
        complete: function () {
            //$(placeholder).removeClass('loading');
        },

    });
};


//Validasyon
//function ZorunlulukKontrol(onEk, deger, errors) {
//    $("input").removeClass("kirmizi");
//    $("select").removeClass("kirmizi");
//    errors = "";
//    var splitDeger = deger.split(",");
//    $.each(splitDeger, function (index, value) {
//        var birlesmis = onEk + value;
//        var labelElement = $("label[for='" + birlesmis + "']");
//        var valueElement = $("#" + birlesmis).val();

//        if (valueElement == null || valueElement == "") {
//            $("#" + birlesmis).addClass("kirmizi");
//            errors += labelElement.text() + ", ";
//        }
//    });
//    if (errors != "") {
//        errors = errors.substring(0, errors.length - 2);
//        errors += " Bu Alanlar Boş Bırakılamaz!";
//    }
//    return errors;
//}

function ZorunlulukKontrol(onEk, deger, errors) {
    $("input").removeClass("kirmizi");
    $("select").removeClass("kirmizi");
    errors = "";
    var splitDeger = deger.split(",");
    $.each(splitDeger, function (index, value) {
        var birlesmis = onEk + value;
        var labelElement = $("label[for='" + birlesmis + "']");
        var valueElement = $("#" + birlesmis).val();
        if ($("#" + birlesmis).prop("tagName") == "INPUT") {
            if (valueElement == null || valueElement == "") {
                $("#" + birlesmis).addClass("kirmizi");
                errors += labelElement.text() + ", ";
            }
        }
        else if ($("#" + birlesmis).prop("tagName") == "SELECT") {
            if (valueElement == null || valueElement == "" || valueElement == 0) {
                $("#" + birlesmis).addClass("kirmizi");
                errors += labelElement.text() + ", ";
            }
        }
    });
    if (errors != "") {
        errors = errors.substring(0, errors.length - 2);
        errors += " Bu Alanlar Boş Bırakılamaz!";
    }
    return errors;
}


function goUrl(url) {
    window.location.href = url;
}

function markaEklePopup(title, label, data, comboBoxId) {
    alertify.prompt(title, label, ''
        , function (evt, value) {
            data.MarkaAd = value;
            post("/AracMarka/Ekle", data, function(e) {
                if (e.Success === true) {
                    alertify.success(e.Message);
                    var url = window.location.origin + "/Arac/ListMarka";
                    getJSONforComboBox(url, null, comboBoxId);
                } else {
                    alertify.error(e.Message);
                };
            });
        }
        , function () {}).set('labels', { ok: 'Kaydet', cancel: 'Vazgeç' });
}

function modelEklePopup(title, label, data, dataModel, markaId, comboBoxId) {
    alertify.prompt(title, label, ''
        , function (evt, value) {
            data.MarkaId = markaId;
            dataModel.ModelAd = value;
            dataModel.MarkaId = markaId;
            data.AracModel = dataModel;
            post("/AracModel/Ekle", data, function (e) {
                if (e.Success === true) {
                    alertify.success(e.Message);
                    var url = window.location.origin + "/Arac/ListModelByMarkaID";
                    var sendData = { markaID: markaId };
                    getJSONforComboBox(url, sendData, comboBoxId);
                } else {
                    alertify.error(e.Message);
                };
            });
        }
        , function () { }).set('labels', { ok: 'Kaydet', cancel: 'Vazgeç' });
}

function versiyonEklePopup(title, label, data, dataModel, modelId, comboBoxId) {
    alertify.prompt(title, label, ''
        , function (evt, value) {
            data.ModelId = modelId;
            dataModel.VersiyonAd = value;
            dataModel.ModelId = modelId;
            data.AracVersiyon = dataModel;
            post("/AracVersiyon/Ekle", data, function (e) {
                if (e.Success === true) {
                    alertify.success(e.Message);
                    var url = window.location.origin + "/Arac/ListVersiyonByModelID";
                    var sendData = { modelID: modelId };
                    getJSONforComboBox(url, sendData, comboBoxId);
                } else {
                    alertify.error(e.Message);
                };
            });
        }
        , function () { }).set('labels', { ok: 'Kaydet', cancel: 'Vazgeç' });
}

function staticDetayEklePopup(title, label, data, dataModel, staticTanimId, comboBoxId, refreshURL) {
    alertify.prompt(title, label, ''
        , function (evt, value) {
            data.StaticTanimId = staticTanimId;
            dataModel.StaticDetayAd = value;
            dataModel.TanimId = staticTanimId;
            data.StaticDetay = dataModel;
            post("/StaticDetay/Ekle", data, function (e) {
                if (e.Success === true) {
                    alertify.success(e.Message);
                    var url = window.location.origin + refreshURL;
                    var sendData = { tanimId: staticTanimId };
                    getJSONforComboBox(url, sendData, comboBoxId);
                } else {
                    alertify.error(e.Message);
                };
            });
        }
        , function () { }).set('labels', { ok: 'Kaydet', cancel: 'Vazgeç' });
}

//comboboxlara bilgi getiren metod
function getJSONforComboBox(url,sendData,name,selectId) {
    $.getJSON(url, sendData,
        function (data) {
            var items = '';
            $(name).empty();
            $.each(data,
                function (i, row) {
                    items += "<option value = '" + row.Value + "'>" + row.Text + "</option>";
                });
            $(name).html(items);
            if (selectId != null || selectId != undefined) {
                $(name).val(selectId);
            }
        });
}
